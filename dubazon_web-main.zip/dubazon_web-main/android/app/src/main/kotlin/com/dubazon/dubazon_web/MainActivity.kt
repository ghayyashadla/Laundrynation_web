package com.dubazon.dubazon_web

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
