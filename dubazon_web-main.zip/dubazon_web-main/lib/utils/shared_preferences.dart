import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Preferences {
  static const _keyRating = 'rating';
  static const _keyRateText = 'rateText';
  static const _keyCurrency = 'currency';

  Future setRating(double rate, String rateText) async {
    SharedPreferences preferences;
    preferences = await SharedPreferences.getInstance();
    preferences.setString(_keyRateText, rateText);
    return preferences.setDouble(_keyRating, rate);
  }

  Future getRating() async {
    SharedPreferences preferences;
    preferences = await SharedPreferences.getInstance();
    return preferences.getDouble(
      _keyRating,
    );
  }

  Future<bool> isRated() async {
    SharedPreferences preferences;
    preferences = await SharedPreferences.getInstance();
    return preferences.containsKey(
      _keyRating,
    );
  }

  Future<bool> isCurrency() async {
    if (kDebugMode) {
      print('called: isCurrency');
    }
    final prefs = await SharedPreferences.getInstance();
    bool b = prefs.containsKey(_keyCurrency);
    return b;
  }

  addCurrency(int c) async {
    if (kDebugMode) {
      print('called: addCurrency');
    }
    final prefs = await SharedPreferences.getInstance();
    prefs.setInt(_keyCurrency, c);
  }

  Future<int> getCurrency() async {
    if (kDebugMode) {
      print('called: getCurrency');
    }
    final prefs = await SharedPreferences.getInstance();
    bool b = prefs.containsKey(_keyCurrency);
    if (b) {
      return prefs.getInt(_keyCurrency)!;
    } else {
      return 0;
    }
  }
}
