import 'package:dubazon/models/user.dart';
import 'package:dubazon/utils/database.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;

  MyUser _userFromFirebaseUser(User? user) {
    return MyUser(
        uid: user!.uid,
        isAnonymous: user.isAnonymous,
        isEmailVerified: user.emailVerified);

    // user != null
    //     ? MyUser(
    //         uid: user.uid,
    //         isAnonymous: user.isAnonymous,
    //         isEmailVerified: user.emailVerified)
    //     : null;
  }

  Stream<MyUser> get user {
    return _auth.authStateChanges().map(_userFromFirebaseUser);
  }

  Future signInAnon() async {
    try {
      UserCredential result = await _auth.signInAnonymously();
      User? user = result.user;
      await DatabaseService(uid: user!.uid, isAnonymous: user.isAnonymous)
          .addUserData(
              user.uid,
              '',
              '',
              '',
              '',
              '',
              '',
              '',
              '',
              const GeoPoint(25.2048, 55.2708),
              '',
              '',
              '',
              Timestamp.now(),
              Timestamp.now(),
              user.isAnonymous,
              user.emailVerified,
              '');
      return _userFromFirebaseUser(user);
    } catch (e) {
      if (kDebugMode) {
        print(e.toString());
      }
      return null;
    }
  }

  Future signInWithEmailAndPassword(String email, String password) async {
    String errorMessage;
    User? user;
    bool isUser = false;
    try {
      isUser = await DatabaseService().userExists(email);
    } catch (e) {
      if (kDebugMode) {
        print(e.toString());
      }
    }
    if (isUser) {
      try {
        UserCredential result = await _auth.signInWithEmailAndPassword(
            email: email, password: password);
        user = result.user;
        await DatabaseService(uid: user!.uid, isAnonymous: user.isAnonymous)
            .storeNotificationToken(); ///////////////////////////////////////////////////////////////////
        return null;
      } catch (error) {
        switch (error) {
          case "ERROR_WEAK_PASSWORD":
            errorMessage = "Your password is too weak";
            break;
          case "ERROR_WRONG_PASSWORD":
          case "wrong-password":
            errorMessage = "Wrong email/password combination.";
            break;
          case "ERROR_USER_NOT_FOUND":
          case "user-not-found":
            errorMessage = "No user found with this email.";
            break;
          case "ERROR_USER_DISABLED":
          case "user-disabled":
            errorMessage = "User disabled.";
            break;
          case "ERROR_TOO_MANY_REQUESTS":
          case "operation-not-allowed":
            errorMessage = "Too many requests to log into this account.";
            break;
          case "ERROR_OPERATION_NOT_ALLOWED":
            errorMessage = "Server error, please try again later.";
            break;
          case "ERROR_INVALID_EMAIL":
          case "invalid-email":
            errorMessage = "Email address is invalid.";
            break;
          default:
            errorMessage = "SignIn failed. Please try again.";
            break;
        }
      }
    } else {
      errorMessage = "This user is not Admin or not even exists";
    }

    if (errorMessage.isNotEmpty) {
      if (kDebugMode) {
        print('Exception @LoginAccount: $errorMessage');
      }
      // return Future.error(errorMessage);
      return errorMessage;
    }
  }

  Future registerWithEmailAndPassword(
      String email,
      String password,
      String name,
      String phone,
      String address,
      final String building,
      final String floor,
      final String apartment,
      GeoPoint location) async {
    User? user;
    String errorMessage;
    try {
      UserCredential result = await _auth.createUserWithEmailAndPassword(
          email: email, password: password);
      user = result.user;
      await DatabaseService(uid: user!.uid, isAnonymous: user.isAnonymous)
          .addUserData(
              user.uid,
              name,
              '',
              '',
              phone,
              address,
              building,
              floor,
              apartment,
              location,
              email,
              '',
              '',
              Timestamp.now(),
              Timestamp.now(),
              user.isAnonymous,
              user.emailVerified,
              'USER');
      // return _userFromFirebaseUser(user);
      return null;
    } catch (error) {
      switch (error) {
        case "ERROR_WEAK_PASSWORD":
          errorMessage = "Your password is too weak";
          break;
        case "ERROR_EMAIL_ALREADY_IN_USE":
        case "account-exists-with-different-credential":
        case "email-already-in-use":
          errorMessage = "Email already used. Go to login page.";
          break;
        case "ERROR_WRONG_PASSWORD":
        case "wrong-password":
          errorMessage = "Wrong email/password combination.";
          break;
        case "ERROR_USER_NOT_FOUND":
        case "user-not-found":
          errorMessage = "No user found with this email.";
          break;
        case "ERROR_USER_DISABLED":
        case "user-disabled":
          errorMessage = "User disabled.";
          break;
        case "ERROR_TOO_MANY_REQUESTS":
        case "operation-not-allowed":
          errorMessage = "Too many requests to log into this account.";
          break;
        case "ERROR_OPERATION_NOT_ALLOWED":
          errorMessage = "Server error, please try again later.";
          break;
        case "ERROR_INVALID_EMAIL":
        case "invalid-email":
          errorMessage = "Email address is invalid.";
          break;
        default:
          errorMessage = "SignUp failed. Please try again.";
          break;
      }
    }

    if (errorMessage.isNotEmpty) {
      if (kDebugMode) {
        print('Exception @createAccount: $errorMessage');
      }
      // return Future.error(errorMessage);
      return errorMessage;
    }
  }

  Future signOut() async {
    try {
      return await _auth.signOut();
    } catch (e) {
      if (kDebugMode) {
        print(e.toString());
      }
      return null;
    }
  }
}
