import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:dubazon/models/member_request.dart';
import 'package:dubazon/models/alert.dart';
import 'package:dubazon/models/package.dart';
import 'package:dubazon/models/price.dart';
import 'package:dubazon/models/request.dart';
import 'package:dubazon/models/user.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class DatabaseService {
  DatabaseService({this.uid, this.isAnonymous});
  final String? uid;
  final bool? isAnonymous;
  final firebaseMessaging = FirebaseMessaging.instance;

  // collection reference
  final CollectionReference userReference =
      FirebaseFirestore.instance.collection('users');

  final CollectionReference requestReference =
      FirebaseFirestore.instance.collection('requests');

  final CollectionReference packageReference =
      FirebaseFirestore.instance.collection('packages');

  final CollectionReference priceReference =
      FirebaseFirestore.instance.collection('Prices');

  final CollectionReference memberRequestReference =
      FirebaseFirestore.instance.collection('membershiprequests');

  final CollectionReference alertsReference =
      FirebaseFirestore.instance.collection('alerts');

  Future addUserData(
    String uid,
    String name,
    String lastName,
    String fname,
    String phone,
    String address,
    String building,
    String floor,
    String apartment,
    GeoPoint location,
    String email,
    String imgUrl,
    String thumbImg,
    Timestamp timestamp,
    Timestamp dateOfBirth,
    bool isAnonymous,
    bool isEmailVerified,
    String type,
  ) async {
    String? token = await FirebaseMessaging.instance.getToken();
    return await userReference.doc(uid).set({
      'uid': uid,
      'name': name,
      'lastName': lastName,
      'fname': fname,
      'phone': phone,
      'address': address,
      'building': building,
      'floor': floor,
      'apartment': apartment,
      'location': location,
      'email': email,
      'imgUrl': imgUrl,
      'thumbImg': thumbImg,
      'token': token,
      'timestamp': timestamp,
      'dateOfBirth': dateOfBirth,
      'isAnonymous': isAnonymous,
      'isEmailVerified': isEmailVerified,
      'type': type,
    });
  }

  Future updateUserData(
    String uid,
    String name,
    String phone,
    String address,
    String building,
    String floor,
    String apartment,
    GeoPoint location,
  ) async {
    return await userReference.doc(uid).update({
      'name': name,
      'phone': phone,
      'address': address,
      'building': building,
      'floor': floor,
      'apartment': apartment,
      'location': location,
    });
  }

  String? vapidKey =
      'BJypCVG9Rboev7Bb-7HWUxwtveVeccwVGZx-ANQH1phNPduaUdX_NqDHYS0-iXVd_TJeITiJumZbCxrmk0wA0-w';
  storeNotificationToken() async {
    String? token =
        await FirebaseMessaging.instance.getToken(vapidKey: vapidKey);
    userReference.doc(uid).set({'token': token}, SetOptions(merge: true));
  }

  Future<String?> getMessagingToken() async {
    String? token;

    await firebaseMessaging
        .requestPermission()
        .timeout(const Duration(seconds: 5))
        .then((value) {
      if (kDebugMode) {
        print(
            'PlatformPushNotificationWeb.getMessagingToken() requestPermission result is $value');
      }
    }).catchError((e) => print(
            "PlatformPushNotificationWeb.getMessagingToken() requestPermission error: $e"));

    await firebaseMessaging.getToken(vapidKey: vapidKey).then((value) {
      if (kDebugMode) {
        print(
            ' PlatformPushNotificationWeb.getMessagingToken() token is $value');
      }
      token = value;
    }).catchError((e) => {
          print(
              "PlatformPushNotificationWeb.getMessagingToken() getToken error: $e")
        });
    userReference.doc(uid).set({'token': token}, SetOptions(merge: true));
    return token;
  }

  UserData _userDataFromSnapshot(DocumentSnapshot snapshot) {
    return UserData(
      uid: snapshot['uid'],
      name: snapshot['name'],
      lastName: snapshot['lastName'],
      fname: snapshot['fname'],
      phone: snapshot['phone'],
      address: snapshot['address'],
      building: snapshot['building'],
      floor: snapshot['floor'],
      apartment: snapshot['apartment'],
      location: snapshot['location'],
      email: snapshot['email'],
      imgUrl: snapshot['imgUrl'],
      thumbImg: snapshot['thumbImg'],
      token: snapshot['token'],
      timestamp: snapshot['timestamp'],
      dateOfBirth: snapshot['dateOfBirth'],
      isAnonymous: snapshot['isAnonymous'],
      isEmailVerified: snapshot['isEmailVerified'],
      type: snapshot['type'],
    );
  }

  Stream<UserData> get userData {
    return userReference.doc(uid).snapshots().map(_userDataFromSnapshot);
  }

  Future<UserData> getUserData() async {
    return _userDataFromSnapshot(await userReference.doc(uid).get());
  }

  Future<bool> userExists(String email) async => (await userReference
          .where("email", isEqualTo: email)
          .where("type", isEqualTo: 'ADMIN')
          .get())
      .docs
      .isNotEmpty;

  Future<String> getUserToken(String _uid) async {
    if (kDebugMode) {
      print('getUserToken of $_uid');
    }
    return _userDataFromSnapshot(await userReference.doc(_uid).get()).token;
  }

  /////////////////////////////Requests/////////////////////////////////

  Future requestPickup(
    final String _uid,
    final String email,
    final String name,
    final String phone,
    final String address,
    final String building,
    final String floor,
    final String apartment,
    final GeoPoint location,
    final String message,
    // final String status,
  ) async {
    DateTime now = DateTime.fromMicrosecondsSinceEpoch(
        Timestamp.now().microsecondsSinceEpoch);
    String expatedPickup = now.add(const Duration(hours: 12)).toString();
    String expatedDilivery = now.add(const Duration(days: 2)).toString();

    var genId = requestReference.doc();
    return await requestReference.doc(genId.id).set({
      'id': genId.id,
      'uid': uid,
      'pkey': FieldValue.increment(-1),
      'email': email,
      'name': name,
      'phone': phone,
      'address': address,
      'building': building,
      'floor': floor,
      'apartment': apartment,
      'location': location,
      'timestamp': Timestamp.now(),
      'message': message,
      'expatedPickup': expatedPickup,
      'expatedDilivery': expatedDilivery,
      'status': 'REQUESTED',
      'pickupMessage': '',
      'pickupTime': Timestamp.now(),
      'cancelMessage': '',
      'cancelTime': Timestamp.now(),
      'completeMessage': '',
      'completeTime': Timestamp.now(),
      'invoiceAmount': '',
    }).then((value) =>
        {notify(_uid, genId.id, '$name requested pickup', '', 'ADMIN')});
  }

  List<Request> requestsListFromSnapshot(QuerySnapshot snapshot) {
    return snapshot.docs.map((doc) {
      return Request(
        doc.get('id'),
        doc.get('uid'),
        doc.get('pkey'),
        doc.get('email'),
        doc.get('name'),
        doc.get('phone'),
        doc.get('address'),
        doc.get('building'),
        doc.get('floor'),
        doc.get('apartment'),
        doc.get('location'),
        doc.get('timestamp'),
        doc.get('message'),
        doc.get('expatedPickup'),
        doc.get('expatedDilivery'),
        doc.get('status'),
        doc.get('pickupMessage'),
        doc.get('pickupTime'),
        doc.get('cancelMessage'),
        doc.get('cancelTime'),
        doc.get('completeMessage'),
        doc.get('completeTime'),
        doc.get('invoiceAmount'),
        doc.data().toString().contains('invoiceNo') ? doc.get('invoiceNo') : '',
      );
    }).toList();
  }

  Stream<List<Request>> get request {
    Query q = requestReference.orderBy('timestamp').limit(2);
    return q.snapshots().map(requestsListFromSnapshot);
  }

  Future<List<Request>> getRequests(DateTime fromDate, DateTime toDate,
      {String? filter}) async {
    if (kDebugMode) {
      print('@database: getRequests called from $fromDate to $toDate');
    }
    Timestamp fromTimestamp = Timestamp.fromDate(fromDate);
    Timestamp toTimestamp = Timestamp.fromDate(toDate);
    QuerySnapshot q;
    if (filter == 'ALL' || filter == null) {
      q = await requestReference
          .where('timestamp', isLessThanOrEqualTo: toTimestamp)
          .where('timestamp', isGreaterThanOrEqualTo: fromTimestamp)
          .orderBy('timestamp', descending: true)
          .limit(50)
          .get();
    } else {
      q = await requestReference
          .where('status', isEqualTo: filter)
          .where('timestamp', isLessThanOrEqualTo: toTimestamp)
          .where('timestamp', isGreaterThanOrEqualTo: fromTimestamp)
          .orderBy('timestamp', descending: true)
          .limit(50)
          .get();
    }

    return requestsListFromSnapshot(q);
  }

  Future acceptRequest(String _uid, String id, String message) {
    return requestReference.doc(id).update({
      'status': 'PACKINGUP',
      'pickupMessage': message,
      'pickupTime': Timestamp.now(),
    }).then((value) => {
          notify(_uid, id, 'Request Accepted',
              'Your Pickup Request is accepted', 'USER')
        });
  }

  Future declineRequest(String _uid, String id, String message) {
    return requestReference.doc(id).update({
      'status': 'CANCELLED',
      'cancelMessage': message,
      'cancelTime': Timestamp.now(),
    }).then((value) => {notify(_uid, id, 'Request Declined', message, 'USER')});
  }

  Future completeRequest(String _uid, String id, String message,
      String invoiceAmount, String invoiceNo) {
    return requestReference.doc(id).update({
      'status': 'COMPLETED',
      'completeMessage': message,
      'completeTime': Timestamp.now(),
      'invoiceAmount': invoiceAmount,
      'invoiceNo': invoiceNo,
    }).then((value) => {
          notify(
              _uid,
              id,
              'Laundry Done',
              'Your laundry is done. It will be back to you as soon as possible. Your bill is $invoiceAmount',
              'USER')
        });
  }

  /////////////////////////////Packages/////////////////////////////////

  Future addPackage(
    final String name,
    final String desc,
    final String price,
    final bool active,
  ) async {
    var genId = packageReference.doc();
    return await packageReference.doc(genId.id).set({
      'id': genId.id,
      'name': name,
      'desc': desc,
      'price': price,
      'timestamp': Timestamp.now(),
      'active': active,
    });
  }

  Future updatePackage(
    final String id,
    final String name,
    final String desc,
    final String price,
    final bool active,
  ) {
    return packageReference.doc(id).update({
      'name': name,
      'desc': desc,
      'price': price,
      'active': active,
    });
  }

  Future deletePackage(String id) {
    return packageReference.doc(id).delete();
  }

  List<Package> packagesListFromSnapshot(QuerySnapshot snapshot) {
    return snapshot.docs.map((doc) {
      return Package(
        doc.get('id'),
        doc.get('name'),
        doc.get('desc'),
        doc.get('price'),
        doc.get('timestamp'),
        doc.get('active'),
      );
    }).toList();
  }

  Stream<List<Package>> get package {
    Query q = packageReference.orderBy('timestamp');
    return q.snapshots().map(packagesListFromSnapshot);
  }

  Future<List<Package>> get getPackages async {
    QuerySnapshot q = await packageReference.orderBy('timestamp').get();
    return packagesListFromSnapshot(q);
  }

  /////////////////////////////Prices/////////////////////////////////

  Future addPrice(
    final String name,
    final String desc,
    final String price,
    final bool active,
  ) async {
    var genId = priceReference.doc();
    return await priceReference.doc(genId.id).set({
      'id': genId.id,
      'name': name,
      'desc': desc,
      'price': price,
      'timestamp': Timestamp.now(),
      'active': active,
    });
  }

  Future updatePrice(
    final String id,
    final String name,
    final String desc,
    final String price,
    final bool active,
  ) {
    return priceReference.doc(id).update({
      'name': name,
      'desc': desc,
      'price': price,
      'active': active,
    });
  }

  Future deletePrice(String id) {
    return priceReference.doc(id).delete();
  }

  List<Price> priceListFromSnapshot(QuerySnapshot snapshot) {
    return snapshot.docs.map((doc) {
      return Price(
        doc.get('id'),
        doc.get('name'),
        doc.get('desc'),
        doc.get('price'),
        doc.get('timestamp'),
        doc.get('active'),
      );
    }).toList();
  }

  Future<List<Price>> get getPrices async {
    QuerySnapshot q = await priceReference.get();
    return priceListFromSnapshot(q);
  }

  /////////////////////////////Member Requests/////////////////////////////////

  Future requestMembership(
    final String package,
    final String name,
    final String email,
    final String phone,
    final String address,
    final GeoPoint location,
  ) async {
    var genId = memberRequestReference.doc();
    return await memberRequestReference.doc(genId.id).set({
      'id': genId.id,
      'uid': uid,
      'package': package,
      'name': name,
      'email': email,
      'phone': phone,
      'address': address,
      'location': location,
      'timestamp': Timestamp.now(),
      'active': true,
    });
  }

  List<MemberRequest> memberRequestListFromSnapshot(QuerySnapshot snapshot) {
    return snapshot.docs.map((doc) {
      return MemberRequest(
        doc.get('id'),
        doc.get('uid'),
        doc.get('package'),
        doc.get('email'),
        doc.get('name'),
        doc.get('phone'),
        doc.get('address'),
        doc.get('location'),
        doc.get('active'),
        doc.get('timestamp'),
      );
    }).toList();
  }

  Stream<List<MemberRequest>> get memberRequest {
    Query q = memberRequestReference.orderBy('timestamp');
    return q.snapshots().map(memberRequestListFromSnapshot);
  }

  Future<List<MemberRequest>> get getMemberRequests async {
    QuerySnapshot q = await memberRequestReference
        .orderBy('timestamp', descending: true)
        .get();

    return memberRequestListFromSnapshot(q);
  }

  ////////////////////////////////////////Alerts/////////////////////////

  Future notify(
    final String _uid,
    final String requestId,
    final String name,
    final String desc,
    final String type,
  ) async {
    if (type == 'ALERT') {
      generateAlert(name, desc);
    } else {
      sendNotification(name, desc, _uid);
    }
    String image = '';
    var genId = alertsReference.doc();
    return await alertsReference.doc(genId.id).set({
      'id': genId.id,
      'uid': _uid,
      'requestId': requestId,
      'name': name,
      'desc': desc,
      'image': image,
      'type': type,
      'timestamp': Timestamp.now(),
      'active': true,
    });
  }

  List<Alert> alertsListFromSnapshot(QuerySnapshot snapshot) {
    return snapshot.docs.map((doc) {
      return Alert(
        doc.get('id'),
        doc.get('uid'),
        doc.get('requestId'),
        doc.get('name'),
        doc.get('desc'),
        doc.get('image'),
        doc.get('type'),
        doc.get('timestamp'),
        doc.get('active'),
      );
    }).toList();
  }

  Stream<List<Alert>> get alert {
    Query q = alertsReference.orderBy('timestamp');
    return q.snapshots().map(alertsListFromSnapshot);
  }

  Future<List<Alert>> get getAlerts async {
    QuerySnapshot q = await alertsReference
        .where('type', whereIn: ['ADMIN', 'ALERT'])
        .orderBy('timestamp', descending: true)
        .limit(30)
        .get();
    return alertsListFromSnapshot(q);
  }

  ////////////////////////////////////////Notification/////////////////////////

  sendNotification(String title, String desc, String _uid) async {
    if (kDebugMode) {
      print("sendNotification Called");
    }
    final data = {
      'click_action': 'FLUTTER_NOTIFICATION_CLICK',
      'id': '1',
      'status': 'done',
      'message': title,
    };
    try {
      String token = await getUserToken(_uid);
      http.Response response =
          await http.post(Uri.parse('https://fcm.googleapis.com/fcm/send'),
              headers: <String, String>{
                'Content-Type': 'application/json',
                'Authorization':
                    'key=AAAA2LAwncA:APA91bEdeikJZZXuamiQoC293C8W0q6tGA6fVAAIF__NBqEKdSkY86emAk2KC3jJ82oTpKZB38nyLlXCaQp6XHEGEhDHsMpgVHDJsmYBKAzO71jAK3aOGwhaBgdkOph5kODTre7CZg1P'
              },
              body: jsonEncode(<String, dynamic>{
                'notification': <String, dynamic>{'title': title, 'body': desc},
                'priority': 'high',
                'data': data,
                'to': token
                // 'to': '/topics/subscription'
              }));
      if (response.statusCode == 200) {
        if (kDebugMode) {
          print("Notification Sended to $token");
        }
      } else {
        if (kDebugMode) {
          print("Error Sending Notification");
        }
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error>>>$e');
      }
    }
  }

  generateAlert(String title, String desc) async {
    if (kDebugMode) {
      print("sendNotification Called");
    }
    final data = {
      'click_action': 'FLUTTER_NOTIFICATION_CLICK',
      'id': '1',
      'status': 'done',
      'message': title,
    };
    try {
      http.Response response =
          await http.post(Uri.parse('https://fcm.googleapis.com/fcm/send'),
              headers: <String, String>{
                'Content-Type': 'application/json',
                'Authorization':
                    'key=AAAA2LAwncA:APA91bEdeikJZZXuamiQoC293C8W0q6tGA6fVAAIF__NBqEKdSkY86emAk2KC3jJ82oTpKZB38nyLlXCaQp6XHEGEhDHsMpgVHDJsmYBKAzO71jAK3aOGwhaBgdkOph5kODTre7CZg1P'
              },
              body: jsonEncode(<String, dynamic>{
                'notification': <String, dynamic>{'title': title, 'body': desc},
                'priority': 'high',
                'data': data,
                'to': '/topics/subscription'
              }));
      if (response.statusCode == 200) {
        if (kDebugMode) {
          print("Alert Sended");
        }
      } else {
        if (kDebugMode) {
          print("Error Sending alert");
        }
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error>>>$e');
      }
    }
  }
}
