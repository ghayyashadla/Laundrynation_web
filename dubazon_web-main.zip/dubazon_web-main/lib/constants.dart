import 'package:flutter/material.dart';

const kScaffoldColor = Color(0xFFF2F2F2);
const kAppBarColor = Colors.transparent;
// const kPrimaryColor = Color(0xFF1D65B9);
const kPrimaryColor = Color(0xFF00BAD3);
const kPrimaryLightColor = Color(0xFF0693E3);
const kPrimaryDarkColor = Color(0xFF092341);
// const kSecondaryColor = Color(0xFFFFE823);
const kSecondaryColor = Color(0xFF00BAD3);
