import 'package:cloud_firestore/cloud_firestore.dart';

class Price {
  final String id;
  final String name;
  final String desc;
  final String price;
  final bool active;
  final Timestamp timestamp;

  Price(this.id, this.name, this.desc, this.price, this.timestamp, this.active);

  // factory Img.fromMap(Map<String, dynamic> parsedJson) {
  //   return Img(
  //       parsedJson["id"],
  //       parsedJson["uid"],
  //       parsedJson["title"],
  //       parsedJson["desc"],
  //       parsedJson["tags"],
  //       parsedJson["imageUrl"],
  //       parsedJson["thumbImage"],
  //       parsedJson["timeStamp"],
  //       parsedJson["uploadUser"],
  //       parsedJson["downloads"],
  //       parsedJson["likes"]);
  // }
}
