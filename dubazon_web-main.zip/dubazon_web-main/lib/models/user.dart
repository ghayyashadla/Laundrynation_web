import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:geoflutterfire/geoflutterfire.dart';

class MyUser {
  final String? uid;
  final bool? isAnonymous;
  final bool? isEmailVerified;
  MyUser({this.uid, this.isAnonymous, this.isEmailVerified});
}

class UserData {
  final String uid;
  final String name;
  final String lastName;
  final String fname;
  final String phone;
  final String address;
  final String building;
  final String floor;
  final String apartment;
  final GeoPoint location;
  final String email;
  final String imgUrl;
  final String thumbImg;
  final String token;
  final Timestamp timestamp;
  final Timestamp dateOfBirth;
  final bool isAnonymous;
  final bool isEmailVerified;
  final String type;
  UserData({
    required this.uid,
    required this.name,
    required this.lastName,
    required this.fname,
    required this.phone,
    required this.address,
    required this.building,
    required this.floor,
    required this.apartment,
    required this.location,
    required this.email,
    required this.imgUrl,
    required this.thumbImg,
    required this.token,
    required this.timestamp,
    required this.dateOfBirth,
    required this.isAnonymous,
    required this.isEmailVerified,
    required this.type,
  });
}
