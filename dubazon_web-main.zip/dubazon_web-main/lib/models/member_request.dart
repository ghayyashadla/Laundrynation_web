import 'package:cloud_firestore/cloud_firestore.dart';

class MemberRequest {
  final String id;
  final String uid;
  final String package;
  final String email;
  final String name;
  final String phone;
  final String address;
  final GeoPoint location;
  final bool active;
  final Timestamp timestamp;

  MemberRequest(this.id, this.uid, this.package, this.email, this.name,
      this.phone, this.address, this.location, this.active, this.timestamp);
}
