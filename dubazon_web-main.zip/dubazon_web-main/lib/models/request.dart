import 'package:cloud_firestore/cloud_firestore.dart';

// enum RequestStatus { REQUESTED, PACKINGUP, COMPLETED, CANCELLED }

class Request {
  final String id;
  final String uid;
  final int pkey;
  final String email;
  final String name;
  final String phone;
  final String address;
  final GeoPoint location;
  final String building;
  final String floor;
  final String apartment;
  final Timestamp timestamp;
  final String message;
  final String expatedPickup;
  final String expatedDilivery;
  final String status;
  final String pickupMessage;
  final Timestamp pickupTime;
  final String cancelMessage;
  final Timestamp cancelTime;
  final String completeMessage;
  final Timestamp completeTime;
  final String invoiceAmount;
  final String invoiceNo;
  Request(
      this.id,
      this.uid,
      this.pkey,
      this.email,
      this.name,
      this.phone,
      this.address,
      this.building,
      this.floor,
      this.apartment,
      this.location,
      this.timestamp,
      this.message,
      this.expatedPickup,
      this.expatedDilivery,
      this.status,
      this.pickupMessage,
      this.pickupTime,
      this.cancelMessage,
      this.cancelTime,
      this.completeMessage,
      this.completeTime,
      this.invoiceAmount,
      this.invoiceNo);
}
