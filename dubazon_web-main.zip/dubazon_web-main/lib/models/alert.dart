import 'package:cloud_firestore/cloud_firestore.dart';

//'ADMIN','USER','ALERT'

class Alert {
  final String id;
  final String uid;
  final String requestId;
  final String name;
  final String desc;
  final String image;
  final String type;
  final Timestamp timestamp;
  final bool active;

  Alert(this.id, this.uid, this.requestId, this.name, this.desc, this.image,
      this.type, this.timestamp, this.active);
}
