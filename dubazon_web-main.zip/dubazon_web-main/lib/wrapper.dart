import 'package:dubazon/models/user.dart';
import 'package:dubazon/views/main/main_page.dart';
import 'package:dubazon/views/login/login_page.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class Wrapper extends StatelessWidget {
  const Wrapper({Key? key}) : super(key: key);
  static String routName = '/wrapper';
  @override
  Widget build(BuildContext context) {
    final user = Provider.of<MyUser>(context);
    if (user.uid == null) {
      return const LoginPage();
    } else {
      return MainPage(user: user);
    }
  }
}
