import 'package:dubazon/constants.dart';
import 'package:dubazon/models/user.dart';
import 'package:dubazon/utils/database.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../../../models/alert.dart';

class AlertList extends StatefulWidget {
  const AlertList({Key? key, required this.user}) : super(key: key);

  final MyUser user;

  @override
  State<AlertList> createState() => AlertListState();
}

class AlertListState extends State<AlertList> {
  late DatabaseService _database;

  List<Alert> _alerts = [];

  getNotifications() async {
    _alerts = await _database.getAlerts;
    if (mounted) setState(() {});
  }

  @override
  void initState() {
    super.initState();
    _database = DatabaseService(
        uid: widget.user.uid!, isAnonymous: widget.user.isAnonymous!);
    getNotifications();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: kScaffoldColor,
      child: ListView.separated(
        padding: const EdgeInsets.fromLTRB(20, 0, 20, 10),
        scrollDirection: Axis.vertical,
        itemCount: _alerts.length,
        shrinkWrap: true,
        physics: const BouncingScrollPhysics(),
        separatorBuilder: (_, __) => const Divider(height: 0.5),
        itemBuilder: (context, index) {
          return Container(
            padding: const EdgeInsets.symmetric(vertical: 6),
            height: 60,
            child: Center(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        _alerts[index].name,
                        style: const TextStyle(
                          color: Colors.black54,
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        _alerts[index].desc,
                        style: const TextStyle(
                          color: Colors.black45,
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                  Text(
                    DateFormat.yMMMd()
                        .add_jm()
                        .format(_alerts[index].timestamp.toDate()),
                    style: const TextStyle(
                      color: Colors.black45,
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}


//  Container(
//             height: 40,
//             width: double.infinity,
//             child: Row(
//               children: [
//                 Text(_alerts[index].name),
//                 Icon(
//                   FontAwesomeIcons.dollarSign,
//                   color: Colors.black,
//                 ),
//                 Icon(
//                   FontAwesomeIcons.rocket,
//                   color: Colors.black,
//                 ),
//                 Icon(
//                   FontAwesomeIcons.thumbtack,
//                   color: Colors.black,
//                 ),
//                 Icon(
//                   FontAwesomeIcons.user,
//                   color: Colors.black,
//                 ),
//                 Icon(
//                   FontAwesomeIcons.d,
//                   color: Colors.black,
//                 ),
//               ],
//             ),
//           );