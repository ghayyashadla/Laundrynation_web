import 'package:dubazon/models/user.dart';
import 'package:dubazon/views/main/widgets/top_nav.dart';
import 'package:dubazon/views/alert/widgets/alert_list.dart';
import 'package:flutter/material.dart';

class AlertPage extends StatefulWidget {
  const AlertPage({Key? key, required this.user, required this.scaffoldKey})
      : super(key: key);
  final MyUser user;
  final GlobalKey<ScaffoldState> scaffoldKey;

  @override
  State<AlertPage> createState() => _AlertPageState();
}

class _AlertPageState extends State<AlertPage> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: topNavigationBar(
          widget.scaffoldKey, 'Notifications', null, () {}, null, null),
      body: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        child: AlertList(
          user: widget.user,
        ),
      ),
    );
  }
}
