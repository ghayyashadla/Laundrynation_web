import 'package:dubazon/constants.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class Filters extends StatefulWidget {
  const Filters({Key? key, this.onTap}) : super(key: key);
  final dynamic onTap;
  @override
  State<Filters> createState() => _FiltersState();
}

class _FiltersState extends State<Filters> {
  String _selected = 'ALL';

  final TextEditingController _fromController = TextEditingController();
  final TextEditingController _toController = TextEditingController();
  DateTime _fromDate = DateTime.now().add(const Duration(days: -7));
  DateTime _toDate = DateTime.now();

  List<String> filters = [
    'ALL',
    'REQUESTED',
    'PACKINGUP',
    'COMPLETED',
    'CANCELLED'
  ];

  refresh() {
    widget.onTap(_selected, _fromDate, _toDate);
  }

  @override
  void initState() {
    super.initState();
    _fromController
      ..text = DateFormat.yMMMd().format(_fromDate)
      ..selection = TextSelection.fromPosition(TextPosition(
          offset: _fromController.text.length,
          affinity: TextAffinity.upstream));
    _toController
      ..text = DateFormat.yMMMd().format(_toDate)
      ..selection = TextSelection.fromPosition(TextPosition(
          offset: _toController.text.length, affinity: TextAffinity.upstream));
    // refresh();
  }

  Future<void> _selectFromDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
        context: context,
        initialDate: _fromDate,
        firstDate: DateTime(2015, 8),
        lastDate: DateTime(2101));
    if (picked != null && picked != _fromDate && mounted) {
      setState(() {
        _fromDate = picked;
      });
      _fromController
        ..text = DateFormat.yMMMd().format(picked)
        ..selection = TextSelection.fromPosition(TextPosition(
            offset: _fromController.text.length,
            affinity: TextAffinity.upstream));
    }
    refresh();
  }

  Future<void> _selectToDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
        context: context,
        initialDate: _toDate,
        firstDate: DateTime(2015, 8),
        lastDate: DateTime(2101));
    if (picked != null && picked != _toDate && mounted) {
      setState(() {
        _toDate = picked;
      });
      _toController
        ..text = DateFormat.yMMMd().format(picked)
        ..selection = TextSelection.fromPosition(TextPosition(
            offset: _toController.text.length,
            affinity: TextAffinity.upstream));
    }
    refresh();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 44,
      color: Colors.white,
      child: Row(
        children: [
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.fromLTRB(20, 10, 20, 10),
              scrollDirection: Axis.horizontal,
              itemCount: filters.length,
              physics: const BouncingScrollPhysics(
                  parent: AlwaysScrollableScrollPhysics()),
              itemBuilder: (context, index) {
                return Container(
                  margin: const EdgeInsets.only(right: 10),
                  height: 24,
                  child: InkWell(
                    splashColor: Colors.transparent,
                    onTap: () {
                      setState(() {
                        _selected = filters[index];
                      });
                      refresh();
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      decoration: BoxDecoration(
                        color: _selected == filters[index]
                            ? kPrimaryColor
                            : Colors.white,
                        border: _selected == filters[index]
                            ? null
                            : Border.all(color: Colors.grey.withOpacity(0.5)),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Center(
                        child: Text(
                          filters[index],
                          style: TextStyle(
                            fontSize: 10,
                            color: _selected == filters[index]
                                ? Colors.white
                                : Colors.grey,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
          Container(
            margin: const EdgeInsets.all(10),
            child: InkWell(
              onTap: () {
                _selectFromDate(context);
              },
              child: Container(
                width: 130,
                padding: const EdgeInsets.symmetric(horizontal: 10),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.grey.withOpacity(0.5)),
                ),
                child: TextField(
                  enabled: false,
                  textAlign: TextAlign.center,
                  textAlignVertical: TextAlignVertical.center,
                  // focusNode: AlwaysDisabledFocusNode(),
                  controller: _fromController,
                  style: const TextStyle(
                    fontSize: 10,
                    color: Colors.grey,
                    fontWeight: FontWeight.bold,
                  ),
                  decoration: const InputDecoration(
                    icon: Icon(
                      Icons.calendar_month_outlined,
                      size: 20,
                    ),
                    border: InputBorder.none,
                    hintText: 'From Date',
                  ),
                  // onTap: () {
                  //   _selectFromDate(context);
                  // },
                ),
              ),
            ),
          ),
          const Text(
            'TO',
            style: TextStyle(
              fontSize: 10,
              color: Colors.grey,
              fontWeight: FontWeight.bold,
            ),
          ),
          Container(
            margin: const EdgeInsets.all(10),
            child: InkWell(
              onTap: () {
                _selectToDate(context);
              },
              child: Container(
                width: 130,
                padding: const EdgeInsets.symmetric(horizontal: 10),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.grey.withOpacity(0.5)),
                ),
                child: TextField(
                  enabled: false,
                  textAlign: TextAlign.center,
                  textAlignVertical: TextAlignVertical.center,
                  // focusNode: AlwaysDisabledFocusNode(),
                  controller: _toController,
                  style: const TextStyle(
                    fontSize: 10,
                    color: Colors.grey,
                    fontWeight: FontWeight.bold,
                  ),
                  decoration: const InputDecoration(
                    icon: Icon(
                      Icons.calendar_month_outlined,
                      size: 20,
                    ),
                    border: InputBorder.none,
                    hintText: 'To Date',
                  ),
                  // onTap: () {
                  //   _selectToDate(context);
                  // },
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class AlwaysDisabledFocusNode extends FocusNode {
  @override
  bool get hasFocus => false;
}
