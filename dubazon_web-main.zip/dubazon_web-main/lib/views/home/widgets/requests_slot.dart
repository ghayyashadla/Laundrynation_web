import 'package:dubazon/constants.dart';
import 'package:dubazon/models/request.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class UserSlot extends StatelessWidget {
  const UserSlot(
      {Key? key,
      required this.request,
      required this.index,
      this.onTap,
      this.onMenu})
      : super(key: key);
  final Request request;
  final int index;
  final Function()? onTap;
  final Function()? onMenu;
  @override
  Widget build(BuildContext context) {
    Color color;
    switch (request.status) {
      case 'REQUESTED':
        color = kPrimaryDarkColor.withOpacity(0.5);
        break;
      case 'PACKINGUP':
        color = kPrimaryColor.withOpacity(0.5);
        break;
      case 'COMPLETED':
        color = Colors.grey.withOpacity(0.5);
        break;
      case 'CANCELLED':
        color = Colors.red.withOpacity(0.5);
        break;
      default:
        color = Colors.grey.withOpacity(0.5);
    }

    return InkWell(
      splashColor: Colors.transparent,
      onTap: onTap,
      child: Container(
        height: 35,
        decoration: BoxDecoration(
          color: index.isEven ? Colors.white : Colors.transparent,
          borderRadius: BorderRadius.circular(10),
        ),
        child: Row(
          children: [
            const SizedBox(width: 10),
            const SizedBox(
              width: 20,
              child: Icon(
                Icons.check_circle,
                color: Colors.grey,
                size: 16,
              ),
            ),
            const SizedBox(width: 10),
            Container(
              margin: const EdgeInsets.symmetric(vertical: 6),
              width: 2,
              height: double.infinity,
              color: Colors.grey.withOpacity(0.5),
            ),
            const SizedBox(width: 10),
            SizedBox(
              width: 50,
              child: Center(
                child: Text(
                  request.pkey.toString(),
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
              ),
            ),
            const SizedBox(width: 10),
            SizedBox(
              width: 120,
              child: Center(
                child: Text(
                  request.name,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
              ),
            ),
            const SizedBox(width: 10),
            SizedBox(
              width: 140,
              child: Center(
                child: Text(
                  DateFormat.yMMMd()
                      .add_jm()
                      .format(request.timestamp.toDate()),
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 12),
                ),
              ),
            ),
            const SizedBox(width: 10),
            SizedBox(
              width: 140,
              child: Center(
                child: Text(
                  request.email,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 12),
                ),
              ),
            ),
            const SizedBox(width: 10),
            SizedBox(
              width: 120,
              child: Center(
                child: Text(
                  request.phone,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 12),
                ),
              ),
            ),
            const SizedBox(width: 10),
            SizedBox(
              width: 120,
              child: Center(
                child: Text(
                  request.invoiceNo,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 12),
                ),
              ),
            ),
            const SizedBox(width: 10),
            SizedBox(
              width: 120,
              child: Center(
                child: Text(
                  request.invoiceAmount,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 12),
                ),
              ),
            ),
            const SizedBox(width: 5),
            const Spacer(),
            const SizedBox(width: 5),
            Container(
              width: 80,
              margin: const EdgeInsets.symmetric(vertical: 6),
              padding: const EdgeInsets.all(4),
              decoration: BoxDecoration(
                color: color,
                borderRadius: BorderRadius.circular(4),
              ),
              child: Center(
                child: Text(
                  request.status,
                  style: const TextStyle(
                    fontSize: 12,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
            const SizedBox(width: 10),
            SizedBox(
              width: 20,
              child: InkWell(
                onTap: onMenu,
                child: const SizedBox(
                  width: 30,
                  child: Icon(
                    Icons.more_horiz,
                    color: Colors.black87,
                    size: 30,
                  ),
                ),
              ),
            ),
            // Material(
            //   color: Colors.transparent,
            //   child: PopupMenuButton(
            //     child: const SizedBox(
            //       width: 30,
            //       child: Icon(
            //         Icons.more_horiz,
            //         color: Colors.black87,
            //         size: 30,
            //       ),
            //     ),
            //     itemBuilder: (context) {
            //       return List.generate(1, (index) {
            //         return PopupMenuItem(
            //           onTap: onMenu,
            //           child: Row(
            //             children: const [
            //               Icon(Icons.send, color: Colors.black),
            //               Text(
            //                 '   Send Notification',
            //                 style: TextStyle(
            //                     fontWeight: FontWeight.bold,
            //                     color: Colors.black),
            //               ),
            //             ],
            //           ),
            //         );
            //       });
            //     },
            //   ),
            // ),
            const SizedBox(width: 20),
          ],
        ),
      ),
    );
  }
}
