import 'dart:collection';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class UserLocation extends StatefulWidget {
  const UserLocation({Key? key, this.location}) : super(key: key);

  final GeoPoint? location;
  @override
  _UserLocationState createState() => _UserLocationState();
}

class _UserLocationState extends State<UserLocation> {
  final Set<Marker> _markers = HashSet<Marker>();
  late GeoPoint point;

  void _onMapCreated(GoogleMapController controller) {
    setState(() {
      // _mapController = controller;
    });
  }

  @override
  void initState() {
    super.initState();
    if (widget.location != null) {
      if (mounted) {
        setState(() {
          point =
              GeoPoint(widget.location!.latitude, widget.location!.longitude);
          _markers.add(
            Marker(
              markerId: const MarkerId('MarkerId'),
              position:
                  LatLng(widget.location!.latitude, widget.location!.longitude),
              infoWindow: const InfoWindow(
                title: '',
                snippet: '',
              ),
            ),
          );
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return GoogleMap(
      onMapCreated: _onMapCreated,
      initialCameraPosition: CameraPosition(
        target: LatLng(widget.location!.latitude, widget.location!.longitude),
        zoom: 14,
      ),
      mapType: MapType.terrain,
      markers: _markers,
      myLocationEnabled: true,
      myLocationButtonEnabled: true,
    );
  }
}
