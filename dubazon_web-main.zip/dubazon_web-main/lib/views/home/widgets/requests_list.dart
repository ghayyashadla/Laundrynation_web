import 'package:dubazon/constants.dart';
import 'package:dubazon/models/request.dart';
import 'package:dubazon/models/user.dart';
import 'package:dubazon/utils/database.dart';
import 'package:dubazon/views/home/widgets/requests_slot.dart';
import 'package:flutter/material.dart';

class RequestsList extends StatefulWidget {
  const RequestsList(
      {Key? key,
      required this.user,
      required this.onPopup,
      required this.onMenu})
      : super(key: key);

  final MyUser user;
  final Function(Request) onPopup;
  final Function(Request) onMenu;

  @override
  State<RequestsList> createState() => RequestsListState();
}

class RequestsListState extends State<RequestsList> {
  late DatabaseService _database;

  List<Request> _requests = [];

  getRequests(
    DateTime fromDate,
    DateTime toDate, {
    String? filter,
  }) async {
    _requests = await _database.getRequests(fromDate, toDate, filter: filter);
    if (mounted) setState(() {});
  }

  @override
  void initState() {
    super.initState();
    _database = DatabaseService(
        uid: widget.user.uid!, isAnonymous: widget.user.isAnonymous!);
    getRequests(DateTime.now().add(const Duration(days: -7)), DateTime.now());
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: kScaffoldColor,
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            height: 30,
            child: Row(
              children: const [
                SizedBox(width: 50),
                SizedBox(
                  width: 50,
                  child: Center(
                    child: Text(
                      'ID',
                      style: TextStyle(fontSize: 12, color: Colors.black87),
                    ),
                  ),
                ),
                SizedBox(width: 10),
                SizedBox(
                  width: 120,
                  child: Center(
                    child: Text(
                      'CUSTOMER',
                      style: TextStyle(fontSize: 12, color: Colors.black87),
                    ),
                  ),
                ),
                SizedBox(width: 10),
                SizedBox(
                  width: 140,
                  child: Center(
                    child: Text(
                      'REQUESTED',
                      style: TextStyle(fontSize: 12, color: Colors.black87),
                    ),
                  ),
                ),
                SizedBox(width: 10),
                SizedBox(
                  width: 140,
                  child: Center(
                    child: Text(
                      'EMAIL',
                      style: TextStyle(fontSize: 12, color: Colors.black87),
                    ),
                  ),
                ),
                SizedBox(width: 10),
                SizedBox(
                  width: 120,
                  child: Center(
                    child: Text(
                      'PHONE',
                      style: TextStyle(fontSize: 12, color: Colors.black87),
                    ),
                  ),
                ),
                SizedBox(width: 10),
                SizedBox(
                  width: 120,
                  child: Center(
                    child: Text(
                      'INVOICE#',
                      style: TextStyle(fontSize: 12, color: Colors.black87),
                    ),
                  ),
                ),
                SizedBox(width: 10),
                SizedBox(
                  width: 120,
                  child: Center(
                    child: Text(
                      'AMOUNT',
                      style: TextStyle(fontSize: 12, color: Colors.black87),
                    ),
                  ),
                ),
                Spacer(),
                SizedBox(
                  width: 80,
                  child: Center(
                    child: Text(
                      'STATUS',
                      style: TextStyle(fontSize: 12, color: Colors.black87),
                    ),
                  ),
                ),
                SizedBox(width: 50),
              ],
            ),
          ),
          ListView.builder(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 10),
            scrollDirection: Axis.vertical,
            itemCount: _requests.length,
            shrinkWrap: true,
            physics: const BouncingScrollPhysics(),
            itemBuilder: (context, index) {
              return UserSlot(
                request: _requests[index],
                index: index,
                onTap: () {
                  widget.onPopup(_requests[index]);
                },
                onMenu: () {
                  widget.onMenu(_requests[index]);
                },
              );
            },
          ),
        ],
      ),
    );
  }
}
