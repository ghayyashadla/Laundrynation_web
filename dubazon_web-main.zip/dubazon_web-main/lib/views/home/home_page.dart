import 'dart:html' show AnchorElement;

import 'dart:convert';
import 'package:dubazon/constants.dart';
import 'package:dubazon/models/request.dart';
import 'package:dubazon/models/user.dart';
import 'package:dubazon/utils/database.dart';
import 'package:dubazon/views/home/widgets/filters.dart';
import 'package:dubazon/views/home/widgets/requests_list.dart';
import 'package:dubazon/views/home/widgets/user_location.dart';
import 'package:dubazon/views/main/widgets/top_nav.dart';
import 'package:dubazon/views/widgets/button.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:form_field_validator/form_field_validator.dart';
import 'package:intl/intl.dart';
import 'package:syncfusion_flutter_xlsio/xlsio.dart' as xlsx;

class HomePage extends StatefulWidget {
  const HomePage({Key? key, required this.user, required this.scaffoldKey})
      : super(key: key);
  final MyUser user;
  final GlobalKey<ScaffoldState> scaffoldKey;

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  late DatabaseService _database;
  String _message = '';
  String _amount = '';
  String _invoice = '';

  GlobalKey<RequestsListState> requestListKey = GlobalKey();

  String? _filter;
  DateTime _fromDate = DateTime.now().add(const Duration(days: -7));
  DateTime _toDate = DateTime.now();

  String? _name, _desc;
  final _formKey = GlobalKey<FormState>();

  final _focus = FocusNode();

  _addDataSheet() {}

  Future<void> createExcel() async {
    String _fileName =
        'Requests_${_fromDate.day}-${_fromDate.month}_to_${_toDate.day}-${_toDate.month}.xlsx';

    final xlsx.Workbook workbook = xlsx.Workbook();
    final xlsx.Worksheet sheet = workbook.worksheets[0];
    sheet.getRangeByName('A1').setText('Hello');
    final List<int> bytes = workbook.saveAsStream();
    workbook.dispose();
    if (kIsWeb) {
      AnchorElement(
          href:
              'data:application/actet-streem;charset-utf-16le;base64,${base64.encode(bytes)}')
        ..setAttribute('download', _fileName)
        ..click();
    } else {}
  }

  _onCreate(String type) {
    if (_formKey.currentState!.validate()) {
      _database
          .notify(widget.user.uid!, '', _name!, _desc!, type)
          .then((value) {
        Navigator.of(context).pop(true);
      });
    }
  }

  Future<void> _onMenuClick(Request request) async {
    return showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        backgroundColor: kScaffoldColor,
        title: Stack(
          children: [
            Positioned(
              top: 0,
              bottom: 0,
              right: 0,
              child: IconButton(
                padding: EdgeInsets.zero,
                onPressed: () => Navigator.of(context).pop(false),
                icon: const Icon(Icons.close_rounded),
              ),
            ),
            Center(
              child: Text(
                'Generate message for ${request.name}',
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
            ),
          ],
        ),
        content: SizedBox(
          width: 500,
          height: 400,
          child: Form(
            key: _formKey,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Container(
                  margin: const EdgeInsets.symmetric(vertical: 10),
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(8),
                    boxShadow: const [
                      BoxShadow(
                        color: Colors.black12,
                        offset: Offset(2, 2),
                        blurRadius: 10,
                      ),
                    ],
                  ),
                  child: TextFormField(
                    initialValue: _name,
                    textInputAction: TextInputAction.next,
                    onFieldSubmitted: (v) {
                      FocusScope.of(context).requestFocus(_focus);
                    },
                    onChanged: (input) => _name = input.trim(),
                    decoration: const InputDecoration(
                      border: InputBorder.none,
                      hintStyle: TextStyle(fontSize: 14),
                      hintText: 'Heading',
                    ),
                    validator: MultiValidator(
                      [
                        RequiredValidator(errorText: 'Required *'),
                      ],
                    ),
                  ),
                ),
                Container(
                  margin: const EdgeInsets.symmetric(vertical: 10),
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(8),
                    boxShadow: const [
                      BoxShadow(
                        color: Colors.black12,
                        offset: Offset(2, 2),
                        blurRadius: 10,
                      ),
                    ],
                  ),
                  child: TextFormField(
                    initialValue: _desc,
                    textInputAction: TextInputAction.next,
                    // onFieldSubmitted: (v) {_onCreate(); },
                    onChanged: (input) => _desc = input.trim(),
                    decoration: const InputDecoration(
                      border: InputBorder.none,
                      hintStyle: TextStyle(fontSize: 14),
                      hintText: 'Description',
                    ),
                    validator: MultiValidator(
                      [
                        RequiredValidator(errorText: 'Required *'),
                      ],
                    ),
                  ),
                ),
                const Spacer(),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Button(
                      text: 'Done',
                      width: 100,
                      onPressed: () => _onCreate('USER'),
                    ),
                  ],
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  refresh() {
    requestListKey.currentState
        ?.getRequests(_fromDate, _toDate, filter: _filter);
  }

  _onDecline(String _uid, String id) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: kScaffoldColor,
        title: const Text('You are declining cuetomer\'s request'),
        content: SizedBox(
          height: 200,
          child: Column(
            children: [
              Container(
                width: double.infinity,
                height: 100,
                // margin: const EdgeInsets.fromLTRB(20, 20, 20, 20),
                padding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(14),
                  boxShadow: const [
                    BoxShadow(
                      color: Colors.black12,
                      offset: Offset(2, 2),
                      blurRadius: 6,
                    ),
                  ],
                ),
                child: TextField(
                  maxLines: 4,
                  textInputAction: TextInputAction.done,
                  style: const TextStyle(color: Colors.black, fontSize: 12),
                  decoration: const InputDecoration(
                    hintText: "Type any message for customer...",
                    border: InputBorder.none,
                    hintStyle: TextStyle(fontSize: 12, color: Colors.black54),
                  ),
                  onChanged: (v) {
                    if (mounted) {
                      setState(() {
                        _message = v;
                      });
                    }
                  },
                ),
              ),
            ],
          ),
        ),
        actions: <Widget>[
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Button(
                text: 'Not Now',
                onPressed: () => Navigator.of(context).pop(false),
              ),
              const SizedBox(width: 6),
              Button(
                text: 'Done',
                color: const Color(0XFFF65151),
                onPressed: () {
                  _database.declineRequest(_uid, id, _message);
                  Navigator.of(context).pop(true);
                  // Navigator.of(context).pop(true);
                  refresh();
                },
              ),
            ],
          ),
        ],
      ),
    );
    return true;
  }

  Future<bool> _onComplete(String _uid, String id) async {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: kScaffoldColor,
        title: const Text('Request is Complete please mention invoice amount'),
        content: SizedBox(
          height: 300,
          child: Column(
            children: [
              Container(
                width: double.infinity,
                // margin: const EdgeInsets.fromLTRB(20, 20, 20, 20),
                padding: const EdgeInsets.symmetric(horizontal: 20),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(14),
                  boxShadow: const [
                    BoxShadow(
                      color: Colors.black12,
                      offset: Offset(2, 2),
                      blurRadius: 6,
                    ),
                  ],
                ),
                child: TextField(
                  textInputAction: TextInputAction.done,
                  style: const TextStyle(color: Colors.black, fontSize: 12),
                  decoration: const InputDecoration(
                    hintText: "Invioce#",
                    border: InputBorder.none,
                    hintStyle: TextStyle(fontSize: 12, color: Colors.black54),
                  ),
                  onChanged: (v) {
                    if (mounted) {
                      setState(() {
                        _invoice = v;
                      });
                    }
                  },
                ),
              ),
              const SizedBox(height: 10),
              Container(
                width: double.infinity,
                // margin: const EdgeInsets.fromLTRB(20, 20, 20, 20),
                padding: const EdgeInsets.symmetric(horizontal: 20),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(14),
                  boxShadow: const [
                    BoxShadow(
                      color: Colors.black12,
                      offset: Offset(2, 2),
                      blurRadius: 6,
                    ),
                  ],
                ),
                child: TextField(
                  textInputAction: TextInputAction.done,
                  style: const TextStyle(color: Colors.black, fontSize: 12),
                  decoration: const InputDecoration(
                    hintText: "Invioce Amount",
                    border: InputBorder.none,
                    hintStyle: TextStyle(fontSize: 12, color: Colors.black54),
                  ),
                  onChanged: (v) {
                    if (mounted) {
                      setState(() {
                        _amount = v;
                      });
                    }
                  },
                ),
              ),
              const SizedBox(height: 10),
              Container(
                width: double.infinity,
                height: 100,
                // margin: const EdgeInsets.fromLTRB(20, 20, 20, 20),
                padding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(14),
                  boxShadow: const [
                    BoxShadow(
                      color: Colors.black12,
                      offset: Offset(2, 2),
                      blurRadius: 6,
                    ),
                  ],
                ),
                child: TextField(
                  maxLines: 4,
                  textInputAction: TextInputAction.done,
                  style: const TextStyle(color: Colors.black, fontSize: 12),
                  decoration: const InputDecoration(
                    hintText: "Type any message for customer...",
                    border: InputBorder.none,
                    hintStyle: TextStyle(fontSize: 12, color: Colors.black54),
                  ),
                  onChanged: (v) {
                    if (mounted) {
                      setState(() {
                        _message = v;
                      });
                    }
                  },
                ),
              ),
            ],
          ),
        ),
        actions: <Widget>[
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Button(
                text: 'Not Now',
                onPressed: () => Navigator.of(context).pop(false),
              ),
              const SizedBox(width: 6),
              Button(
                text: 'Done',
                onPressed: () {
                  _database.completeRequest(
                      _uid, id, _message, _amount, _invoice);
                  Navigator.of(context).pop(true);
                  // Navigator.of(context).pop(true);
                  refresh();
                },
              ),
            ],
          ),
        ],
      ),
    );
    return true;
  }

  Future<bool> _onAccept(String _uid, String id) async {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: kScaffoldColor,
        title: const Text('You are accepting pickup request'),
        content: Container(
          width: double.infinity,
          height: 100,
          // margin: const EdgeInsets.fromLTRB(20, 20, 20, 20),
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(14),
            boxShadow: const [
              BoxShadow(
                color: Colors.black12,
                offset: Offset(2, 2),
                blurRadius: 6,
              ),
            ],
          ),
          child: TextField(
            maxLines: 4,
            textInputAction: TextInputAction.done,
            style: const TextStyle(color: Colors.black, fontSize: 12),
            decoration: const InputDecoration(
              hintText: "Type any message for customer...",
              border: InputBorder.none,
              hintStyle: TextStyle(fontSize: 12, color: Colors.black54),
            ),
            onChanged: (v) {
              if (mounted) {
                setState(() {
                  _message = v;
                });
              }
            },
          ),
        ),
        actions: <Widget>[
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Button(
                text: 'Not Now',
                onPressed: () => Navigator.of(context).pop(false),
              ),
              const SizedBox(width: 6),
              Button(
                text: 'Done',
                onPressed: () {
                  _database.acceptRequest(_uid, id, _message);
                  Navigator.of(context).pop(true);
                  // Navigator.of(context).pop(true);
                  refresh();
                },
              ),
            ],
          ),
        ],
      ),
    );
    return true;
  }

  Future<bool> _onClick(Request request) async {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        backgroundColor: kScaffoldColor,
        title: Stack(
          children: [
            Positioned(
              top: 0,
              bottom: 0,
              right: 0,
              child: IconButton(
                padding: EdgeInsets.zero,
                onPressed: () => Navigator.of(context).pop(false),
                icon: const Icon(Icons.close_rounded),
              ),
            ),
            const Center(
              child: Text(
                'Request Status',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
            ),
          ],
        ),
        content: SizedBox(
          width: 500,
          height: 400,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Expanded(
                    child: Text(
                      'ID: ${request.pkey}',
                      style: const TextStyle(color: Colors.black, fontSize: 12),
                    ),
                  ),
                  Expanded(
                    child: Text(
                      'Requested: ${DateFormat.yMMMd().add_jm().format(request.timestamp.toDate())}',
                      style: const TextStyle(color: Colors.black, fontSize: 12),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 6),
              const Text(
                'Customer Information',
                style: TextStyle(
                    color: Colors.black,
                    fontSize: 16,
                    fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 6),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Expanded(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Name: ${request.name}',
                          style: const TextStyle(
                              color: Colors.black, fontSize: 12),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          'Builidng: ${request.building},',
                          style: const TextStyle(
                              color: Colors.black, fontSize: 12),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          'Floor/Apartment: ${request.floor} / ${request.apartment}',
                          style: const TextStyle(
                              color: Colors.black, fontSize: 12),
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Email: ${request.email}',
                          style: const TextStyle(
                              color: Colors.black, fontSize: 12),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          'Phone: ${request.phone}',
                          style: const TextStyle(
                              color: Colors.black, fontSize: 12),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 6),
              Expanded(
                child: UserLocation(location: request.location),
              ),
            ],
          ),
        ),
        actions: <Widget>[
          if (request.status == 'REQUESTED')
            Button(
              text: 'Decline',
              color: const Color(0XFFF65151),
              width: 100,
              onPressed: () => _onDecline(request.uid, request.id),
            ),
          if (request.status == 'REQUESTED')
            Button(
              text: 'Accept',
              width: 100,
              onPressed: () => _onAccept(request.uid, request.id),
            ),
          if (request.status == 'PACKINGUP')
            Button(
              text: 'Complete',
              width: 100,
              onPressed: () => _onComplete(request.uid, request.id),
            ),
        ],
      ),
    );
    return true;
  }

  @override
  void initState() {
    super.initState();
    _database = DatabaseService(
        uid: widget.user.uid!, isAnonymous: widget.user.isAnonymous!);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: topNavigationBar(widget.scaffoldKey, 'Pickup Requests', 'Refresh',
          () async => refresh(), 'Generate Excel', createExcel),
      body: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        child: Container(
          color: kScaffoldColor,
          child: Column(
            children: [
              Filters(
                onTap: (String filter, DateTime fromDate, DateTime toDate) {
                  setState(() {
                    _filter = filter;
                    _fromDate = fromDate;
                    _toDate = toDate;
                  });
                  refresh();
                  //  requestListKey.currentState?.getRequests(filter: filter)
                },
              ),
              RequestsList(
                key: requestListKey,
                user: widget.user,
                onPopup: _onClick,
                onMenu: _onMenuClick,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
