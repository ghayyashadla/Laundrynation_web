import 'package:dubazon/constants.dart';
import 'package:dubazon/models/package.dart';
import 'package:dubazon/models/price.dart';
import 'package:dubazon/models/user.dart';
import 'package:dubazon/utils/database.dart';
import 'package:dubazon/views/packages/widgets/package_form.dart';
import 'package:dubazon/views/packages/widgets/package_card.dart';
import 'package:dubazon/views/main/widgets/top_nav.dart';
import 'package:dubazon/views/packages/widgets/price_card.dart';
import 'package:dubazon/views/packages/widgets/price_form.dart';
import 'package:flutter/material.dart';

class PackagesPage extends StatefulWidget {
  const PackagesPage({Key? key, required this.user, required this.scaffoldKey})
      : super(key: key);
  final MyUser user;
  final GlobalKey<ScaffoldState> scaffoldKey;

  @override
  State<PackagesPage> createState() => _PackagesPageState();
}

class _PackagesPageState extends State<PackagesPage>
    with TickerProviderStateMixin {
  late DatabaseService _database;
  List<Package> _packages = [];

  List<Price> _prices = [];

  refresh() {
    _getPackages();
    _getPrices();
  }

  _onTap({Package? package}) async {
    return showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        backgroundColor: kScaffoldColor,
        title: Stack(
          children: [
            Positioned(
              top: 0,
              bottom: 0,
              right: 0,
              child: IconButton(
                padding: EdgeInsets.zero,
                onPressed: () => Navigator.of(context).pop(false),
                icon: const Icon(Icons.close_rounded),
              ),
            ),
            const Center(
              child: Text(
                'Package Information',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
            ),
          ],
        ),
        content: SizedBox(
          width: 500,
          height: 400,
          child: PackageForm(
            user: widget.user,
            package: package,
            refresh: refresh,
          ),
        ),
      ),
    );
  }

  _onTapPrice({Price? price}) async {
    return showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        backgroundColor: kScaffoldColor,
        title: Stack(
          children: [
            Positioned(
              top: 0,
              bottom: 0,
              right: 0,
              child: IconButton(
                padding: EdgeInsets.zero,
                onPressed: () => Navigator.of(context).pop(false),
                icon: const Icon(Icons.close_rounded),
              ),
            ),
            const Center(
              child: Text(
                'Product Detail',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
            ),
          ],
        ),
        content: SizedBox(
          width: 500,
          height: 400,
          child: PriceForm(
            user: widget.user,
            price: price,
            refresh: refresh,
          ),
        ),
      ),
    );
  }

  _getPackages() async {
    _packages = await _database.getPackages;
    if (mounted) setState(() {});
  }

  _getPrices() async {
    _prices = await _database.getPrices;
    if (mounted) setState(() {});
  }

  @override
  void initState() {
    super.initState();
    _database = DatabaseService(
        uid: widget.user.uid!, isAnonymous: widget.user.isAnonymous!);
    _getPackages();
    _getPrices();
  }

  @override
  Widget build(BuildContext context) {
    const kPrimaryColor = Color(0xFF1D65B9);
    return Scaffold(
      appBar: topNavigationBar(
        widget.scaffoldKey,
        'Our Packages',
        'New Package',
        _onTap,
        'New Product',
        _onTapPrice,
      ),
      body: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ListView.builder(
              scrollDirection: Axis.vertical,
              itemCount: _packages.length,
              shrinkWrap: true,
              physics: const ClampingScrollPhysics(),
              itemBuilder: (context, index) {
                switch (index) {
                  case 0:
                    {
                      return PackageCard(
                        name: _packages[index].name,
                        desc: _packages[index].desc.replaceAll("\\n", "\n"),
                        price: _packages[index].price,
                        color: Colors.white,
                        borderColor: kPrimaryColor,
                        textColor: kPrimaryColor,
                        buttonText: _packages[index].active
                            ? 'REQUEST NOW'
                            : 'COMING SOON!',
                        buttonColor: kSecondaryColor,
                        buttonTextColor: Colors.black,
                        onTap: () => _onTap(package: _packages[index]),
                      );
                    }
                  case 1:
                    {
                      return PackageCard(
                        name: _packages[index].name,
                        desc: _packages[index].desc.replaceAll("\\n", "\n"),
                        price: _packages[index].price,
                        color: kPrimaryLightColor,
                        borderColor: kPrimaryLightColor,
                        textColor: Colors.white,
                        buttonText: _packages[index].active
                            ? 'REQUEST NOW'
                            : 'COMING SOON!',
                        buttonColor: kPrimaryColor,
                        buttonTextColor: Colors.white,
                        onTap: () => _onTap(package: _packages[index]),
                      );
                    }
                  case 2:
                    {
                      return PackageCard(
                        name: _packages[index].name,
                        desc: _packages[index].desc.replaceAll("\\n", "\n"),
                        price: _packages[index].price,
                        color: kSecondaryColor,
                        borderColor: kSecondaryColor,
                        textColor: kPrimaryColor,
                        buttonText: _packages[index].active
                            ? 'REQUEST NOW'
                            : 'COMING SOON!',
                        buttonColor: kPrimaryColor,
                        buttonTextColor: Colors.white,
                        onTap: () => _onTap(package: _packages[index]),
                      );
                    }
                  default:
                    {
                      return PackageCard(
                        name: _packages[index].name,
                        desc: _packages[index].desc.replaceAll("\\n", "\n"),
                        price: _packages[index].price,
                        color: Colors.white,
                        borderColor: kPrimaryColor,
                        textColor: kPrimaryColor,
                        buttonText: _packages[index].active
                            ? 'REQUEST NOW'
                            : 'COMING SOON!',
                        buttonColor: kSecondaryColor,
                        buttonTextColor: Colors.black,
                        onTap: () => _onTap(package: _packages[index]),
                      );
                    }
                }
              },
            ),
            Container(
              margin: EdgeInsets.fromLTRB(40, 20, 20, 20),
              child: const Text(
                'Pricing Table',
                style:
                    TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
              ),
            ),
            ListView.builder(
              scrollDirection: Axis.vertical,
              // padding: EdgeInsets.fromLTRB(0, 10, 20, 0),
              itemCount: _prices.length,
              shrinkWrap: true,
              physics: ClampingScrollPhysics(),
              itemBuilder: (context, index) {
                return PriceCard(
                  name: _prices[index].name,
                  desc: _prices[index].desc.replaceAll("\\n", "\n"),
                  price: _prices[index].price,
                  onTap: () => _onTapPrice(price: _prices[index]),
                );
              },
            ),
            SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}
