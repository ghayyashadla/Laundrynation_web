import 'package:dubazon/models/package.dart';
import 'package:dubazon/models/price.dart';
import 'package:dubazon/models/user.dart';
import 'package:dubazon/utils/database.dart';
import 'package:dubazon/views/widgets/button.dart';
import 'package:flutter/material.dart';
import 'package:form_field_validator/form_field_validator.dart';

class PriceForm extends StatefulWidget {
  const PriceForm({Key? key, required this.user, this.price, this.refresh})
      : super(key: key);

  final MyUser user;
  final Price? price;
  final dynamic refresh;

  @override
  State<PriceForm> createState() => _PriceFormState();
}

class _PriceFormState extends State<PriceForm> {
  late DatabaseService _database;
  final _formKey = GlobalKey<FormState>();
  String? _id, _name, _desc, _price;
  bool _active = false;

  final _descFocus = FocusNode();
  final _priceFocus = FocusNode();

  _onCreate() {
    if (_formKey.currentState!.validate()) {
      _database.addPrice(_name!, _desc!, _price!, _active).then((value) {
        Navigator.of(context).pop(false);
        widget.refresh();
      });
    }
  }

  _onUpdate(String id) {
    if (_formKey.currentState!.validate()) {
      _database
          .updatePrice(_id!, _name!, _desc!, _price!, _active)
          .then((value) {
        Navigator.of(context).pop(false);
        widget.refresh();
      });
    }
  }

  _onDelete(String id) {
    if (_formKey.currentState!.validate()) {
      _database.deletePrice(id).then((value) {
        Navigator.of(context).pop(false);
        widget.refresh();
      });
    }
  }

  @override
  void initState() {
    super.initState();
    _database = DatabaseService(
        uid: widget.user.uid!, isAnonymous: widget.user.isAnonymous!);

    if (mounted) {
      setState(() {
        if (widget.price != null) {
          _id = widget.price!.id;
          _name = widget.price!.name;
          _desc = widget.price!.desc;
          _price = widget.price!.price;
          _active = widget.price!.active;
        } else {
          _id = null;
          _name = null;
          _desc = null;
          _price = null;
          _active = false;
        }
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Container(
            margin: const EdgeInsets.symmetric(vertical: 10),
            padding: const EdgeInsets.symmetric(horizontal: 10),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(8),
              boxShadow: const [
                BoxShadow(
                  color: Colors.black12,
                  offset: Offset(2, 2),
                  blurRadius: 10,
                ),
              ],
            ),
            child: TextFormField(
              initialValue: _name,
              textInputAction: TextInputAction.next,
              onFieldSubmitted: (v) {
                FocusScope.of(context).requestFocus(_descFocus);
              },
              onChanged: (input) => _name = input.trim(),
              decoration: const InputDecoration(
                border: InputBorder.none,
                hintStyle: TextStyle(fontSize: 14),
                hintText: 'Product Heading',
              ),
              validator: MultiValidator(
                [
                  RequiredValidator(errorText: 'Required *'),
                ],
              ),
            ),
          ),
          Container(
            margin: const EdgeInsets.symmetric(vertical: 10),
            padding: const EdgeInsets.symmetric(horizontal: 10),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(8),
              boxShadow: const [
                BoxShadow(
                  color: Colors.black12,
                  offset: Offset(2, 2),
                  blurRadius: 10,
                ),
              ],
            ),
            child: TextFormField(
              initialValue: _desc,
              textInputAction: TextInputAction.next,
              onFieldSubmitted: (v) {
                FocusScope.of(context).requestFocus(_priceFocus);
              },
              onChanged: (input) => _desc = input.trim(),
              decoration: const InputDecoration(
                border: InputBorder.none,
                hintStyle: TextStyle(fontSize: 14),
                hintText: 'Product Description',
              ),
              validator: MultiValidator(
                [
                  RequiredValidator(errorText: 'Required *'),
                ],
              ),
            ),
          ),
          Container(
            margin: const EdgeInsets.symmetric(vertical: 10),
            padding: const EdgeInsets.symmetric(horizontal: 10),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(8),
              boxShadow: const [
                BoxShadow(
                  color: Colors.black12,
                  offset: Offset(2, 2),
                  blurRadius: 10,
                ),
              ],
            ),
            child: TextFormField(
              initialValue: _price,
              textInputAction: TextInputAction.next,
              onFieldSubmitted: (v) {
                FocusScope.of(context).requestFocus(_descFocus);
              },
              onChanged: (input) => _price = input.trim(),
              decoration: const InputDecoration(
                border: InputBorder.none,
                hintStyle: TextStyle(fontSize: 14),
                hintText: 'Price',
              ),
              validator: MultiValidator(
                [
                  RequiredValidator(errorText: 'Required *'),
                ],
              ),
            ),
          ),
          // Row(
          //   mainAxisAlignment: MainAxisAlignment.end,
          //   children: [
          //     Text(
          //       _active ? 'Active' : 'Inactive',
          //       textAlign: TextAlign.center,
          //       style: const TextStyle(fontSize: 12, color: Colors.black54),
          //     ),
          //     Switch(
          //       onChanged: (v) {
          //         {
          //           if (_active == false) {
          //             setState(() {
          //               _active = true;
          //             });
          //           } else {
          //             setState(() {
          //               _active = false;
          //             });
          //           }
          //         }
          //       },
          //       value: _active,
          //     ),
          //   ],
          // ),
          const Spacer(),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              if (widget.price != null)
                Button(
                  text: 'Delete',
                  color: const Color(0XFFF65151),
                  width: 100,
                  onPressed: () => _onDelete(widget.price!.id),
                ),
              const SizedBox(width: 6),
              if (widget.price != null)
                Button(
                  text: 'Update',
                  width: 100,
                  onPressed: () => _onUpdate(widget.price!.id),
                ),
              if (widget.price == null)
                Button(
                  text: 'Create',
                  width: 100,
                  onPressed: () => _onCreate(),
                ),
            ],
          )
        ],
      ),
    );
  }
}
