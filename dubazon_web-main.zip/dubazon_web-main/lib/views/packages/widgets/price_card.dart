import 'package:flutter/material.dart';

class PriceCard extends StatelessWidget {
  const PriceCard({
    Key? key,
    required this.name,
    required this.desc,
    required this.price,
    required this.onTap,
  }) : super(key: key);
  final String name;
  final String desc;
  final String price;
  final onTap;
  @override
  Widget build(BuildContext context) {
    const kPrimaryColor = Color(0xFF1D65B9);
    return Stack(children: [
      Container(
        width: double.infinity,
        margin: EdgeInsets.fromLTRB(20, 10, 20, 0),
        padding: EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: kPrimaryColor, width: 1),
          boxShadow: const [
            BoxShadow(
              color: Colors.black26,
              offset: Offset(2, 2),
              blurRadius: 10,
            ),
          ],
        ),
        child: InkWell(
          onTap: onTap,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    name,
                    style: TextStyle(
                      fontSize: 20,
                      color: kPrimaryColor,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    price,
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
              SizedBox(height: 3),
              Text(
                desc,
                style: TextStyle(
                    fontSize: 12, color: Colors.black.withOpacity(0.8)),
              ),
            ],
          ),
        ),
      ),
    ]);
  }
}
