import 'package:flutter/material.dart';

class PackageCard extends StatelessWidget {
  const PackageCard(
      {Key? key,
      required this.name,
      required this.desc,
      required this.price,
      required this.color,
      required this.borderColor,
      required this.textColor,
      required this.buttonText,
      required this.buttonColor,
      required this.buttonTextColor,
      this.onTap})
      : super(key: key);
  final String name;
  final String desc;
  final String price;
  final Color color;
  final Color borderColor;
  final Color textColor;
  final String buttonText;
  final Color buttonColor;
  final Color buttonTextColor;
  final Function()? onTap;
  @override
  Widget build(BuildContext context) {
    const kPrimaryColor = Color(0xFF1D65B9);
    return Stack(
      children: [
        Container(
          // height: 160,
          width: 400,
          margin: const EdgeInsets.fromLTRB(20, 10, 20, 0),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: borderColor, width: 1),
            boxShadow: const [
              BoxShadow(
                color: Colors.black26,
                offset: Offset(2, 2),
                blurRadius: 10,
              ),
            ],
          ),
          child: Column(
            children: [
              Text(
                name,
                style: TextStyle(
                  fontSize: 20,
                  color: textColor,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 3),
              Text(
                desc,
                textAlign: TextAlign.center,
                style:
                    TextStyle(fontSize: 12, color: textColor.withOpacity(0.8)),
              ),
              const SizedBox(height: 5),
              InkWell(
                onTap: () {},
                child: Container(
                  width: 160,
                  height: 30,
                  decoration: BoxDecoration(
                    color: buttonColor,
                    borderRadius: BorderRadius.circular(100),
                  ),
                  child: Center(
                    child: Text(
                      buttonText,
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 12, color: buttonTextColor),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
        Positioned(
          left: 15,
          top: 20,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 70,
                height: 30,
                color: kPrimaryColor,
                child: Center(
                  child: Text(
                    price,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      fontSize: 14,
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
              CustomPaint(
                painter: _TrianglePainter(kPrimaryColor),
                child: const SizedBox(
                  width: 5,
                  height: 5,
                ),
              ),
            ],
          ),
        ),
        Positioned(
          left: 350,
          top: 20,
          child: ElevatedButton(
            style: ElevatedButton.styleFrom(
              primary: kPrimaryColor,
            ),
            onPressed: onTap,
            child: const Icon(Icons.edit),
          ),
        ),
      ],
    );
  }
}

class _TrianglePainter extends CustomPainter {
  final Color color;
  _TrianglePainter(this.color);
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint();
    paint.color = color;
    var path = Path();
    path.lineTo(size.width, 0);
    path.lineTo(size.height, size.width);
    path.close();
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) => false;
}
