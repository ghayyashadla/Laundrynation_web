import 'package:dubazon/constants.dart';
import 'package:dubazon/utils/auth.dart';
import 'package:dubazon/views/widgets/button.dart';
import 'package:dubazon/views/widgets/loading.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:form_field_validator/form_field_validator.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({Key? key}) : super(key: key);

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final AuthService _auth = AuthService();

  String? _email, _password;
  String error = '';

  bool isSubmitting = false;

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final focus = FocusNode();
  // LatLng l = const LatLng(25.2048, 55.2708);

  onSubmit() async {
    if (_formKey.currentState!.validate()) {
      setState(() {
        isSubmitting = true;
      });
      dynamic result = await _auth.signInWithEmailAndPassword(
        _email ?? '',
        _password ?? '',
      );
      //     dynamic result = await _auth.registerWithEmailAndPassword(_email ?? '',
      // _password ?? '', '', '', '', GeoPoint(l.latitude, l.longitude));
      if (result == null) {
        if (kDebugMode) {
          print(
              'Completed @LoginAccount: Successfully login into your account');
        }

        // Navigator.push(
        //   context,
        //   MaterialPageRoute(
        //     builder: (context) => RequestsPage(user: user),
        //   ),
        // );
      } else {
        if (kDebugMode) {
          print('Error @LoginAccount: $result');
        }
        if (mounted) {
          setState(() {
            isSubmitting = false;
            error = result;
          });
        }
        // Scaffold.of(context).showSnackBar(SnackBar(content: Text(error)));
      }
    }
  }

  keyboardPress(String text) async {
    await onSubmit();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kScaffoldColor,
      body: Stack(
        children: [
          Image.asset(
            'assets/images/login_bg1.jpg',
            width: double.infinity,
            repeat: ImageRepeat.repeat,
          ),
          Center(
            child: Container(
              width: 400,
              height: 400,
              decoration: BoxDecoration(
                color: kScaffoldColor,
                borderRadius: BorderRadius.circular(20),
                boxShadow: const [
                  BoxShadow(
                    color: Colors.black26,
                    offset: Offset(2, 2),
                    blurRadius: 10,
                  ),
                ],
              ),
              child: Form(
                key: _formKey,
                autovalidateMode: AutovalidateMode.always,
                child: Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: Column(
                    children: [
                      Expanded(
                        flex: 4,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: const [
                            Text(
                              'Welcome Back',
                              style: TextStyle(
                                color: Colors.black87,
                                fontWeight: FontWeight.w600,
                                fontSize: 34,
                              ),
                            ),
                            Text(
                              'Please login to continue using app.',
                              style: TextStyle(
                                color: Colors.black54,
                                fontSize: 12,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Expanded(
                        flex: 10,
                        child: Scaffold(
                          backgroundColor: Colors.transparent,
                          resizeToAvoidBottomInset: true,
                          body: isSubmitting
                              ? const Center(
                                  child: Loading(),
                                )
                              : ListView(
                                  children: [
                                    Container(
                                      margin: const EdgeInsets.symmetric(
                                          vertical: 10),
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 10),
                                      decoration: BoxDecoration(
                                        color: Colors.white,
                                        borderRadius: BorderRadius.circular(8),
                                        boxShadow: const [
                                          BoxShadow(
                                            color: Colors.black12,
                                            offset: Offset(2, 2),
                                            blurRadius: 10,
                                          ),
                                        ],
                                      ),
                                      child: TextFormField(
                                        textInputAction: TextInputAction.next,
                                        onFieldSubmitted: (v) {
                                          FocusScope.of(context)
                                              .requestFocus(focus);
                                        },
                                        onChanged: (input) =>
                                            _email = input.trim(),
                                        decoration: const InputDecoration(
                                          border: InputBorder.none,
                                          suffixIcon: Icon(
                                            Icons.email,
                                            color: Colors.black54,
                                          ),
                                          hintStyle: TextStyle(fontSize: 14),
                                          hintText: 'Email',
                                        ),
                                        validator: MultiValidator(
                                          [
                                            RequiredValidator(
                                                errorText: 'Required *'),
                                            EmailValidator(
                                                errorText: 'Not a valid Email'),
                                          ],
                                        ),
                                      ),
                                    ),
                                    Container(
                                      margin: const EdgeInsets.symmetric(
                                          vertical: 10),
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 10),
                                      decoration: BoxDecoration(
                                        color: Colors.white,
                                        borderRadius: BorderRadius.circular(8),
                                        boxShadow: const [
                                          BoxShadow(
                                            color: Colors.black12,
                                            offset: Offset(2, 2),
                                            blurRadius: 10,
                                          ),
                                        ],
                                      ),
                                      child: TextFormField(
                                        focusNode: focus,
                                        onFieldSubmitted: (v) =>
                                            keyboardPress(v),
                                        onChanged: (input) =>
                                            _password = input.trim(),
                                        obscureText: true,
                                        decoration: const InputDecoration(
                                          border: InputBorder.none,
                                          suffixIcon: Icon(
                                            Icons.vpn_key,
                                            color: Colors.black54,
                                          ),
                                          hintStyle: TextStyle(fontSize: 14),
                                          hintText: 'Password',
                                        ),
                                        validator: MultiValidator(
                                          [
                                            RequiredValidator(
                                                errorText: 'Required *'),
                                            MinLengthValidator(6,
                                                errorText:
                                                    'Should be at least six characters'),
                                            MaxLengthValidator(15,
                                                errorText:
                                                    'Should not be greater than fifteen characters'),
                                          ],
                                        ),
                                      ),
                                    ),
                                    Text(
                                      error,
                                      style: const TextStyle(
                                          color: Colors.black87),
                                    ),
                                    Button(
                                      height: 35,
                                      text: 'Sign In',
                                      onPressed: () => onSubmit(),
                                    ),
                                    const SizedBox(height: 10),
                                  ],
                                ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
