import 'dart:math' as math;
import 'package:flutter/material.dart';

class Loading extends StatefulWidget {
  const Loading(
      {Key? key, this.width, this.height, this.color = Colors.black54})
      : super(key: key);
  final double? width, height;
  final Color? color;

  @override
  State<Loading> createState() => _LoadingState();
}

class _LoadingState extends State<Loading> with SingleTickerProviderStateMixin {
  late final AnimationController _controller =
      AnimationController(vsync: this, duration: const Duration(seconds: 1))
        ..repeat();
  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        children: [
          SizedBox(
            width: widget.width,
            height: widget.height,
            child: Stack(
              alignment: Alignment.center,
              children: [
                Image.asset(
                  'assets/images/loading_base.png',
                  color: widget.color,
                  width: widget.width,
                  height: widget.height,
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 20.0),
                  child: AnimatedBuilder(
                    animation: _controller,
                    builder: (_, child) {
                      return Transform.rotate(
                        angle: _controller.value * 2 * math.pi,
                        child: child,
                      );
                    },
                    child: Padding(
                      padding: const EdgeInsets.only(top: 4.0),
                      child: Image.asset(
                        'assets/images/loading_front.png',
                        color: widget.color,
                        width: widget.width == null
                            ? widget.width
                            : (widget.width! - (widget.width! / 2)),
                        height: widget.height == null
                            ? widget.height
                            : (widget.height! - (widget.height! / 2)),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
