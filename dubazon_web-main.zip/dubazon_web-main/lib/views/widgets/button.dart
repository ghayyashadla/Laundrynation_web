import 'package:dubazon/constants.dart';
import 'package:flutter/material.dart';

class Button extends StatelessWidget {
  const Button({
    Key? key,
    this.text = '',
    this.width,
    this.height,
    this.color = kSecondaryColor,
    this.textColor = Colors.black,
    this.boxShadow = false,
    this.onPressed,
  }) : super(key: key);
  final String text;
  final double? width;
  final double? height;
  final Color color;
  final Color textColor;
  final bool boxShadow;
  final Function()? onPressed;

  @override
  Widget build(BuildContext context) {
    return Hero(
      tag: 'button',
      child: Material(
        child: InkWell(
          onTap: onPressed,
          child: Container(
            width: width,
            height: height,
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
              color: color,
              borderRadius: BorderRadius.circular(8),
              boxShadow: [
                if (boxShadow)
                  const BoxShadow(
                    color: Colors.black12,
                    offset: Offset(2, 2),
                    blurRadius: 10,
                  ),
              ],
            ),
            child: Center(
              child: Text(
                text,
                textAlign: TextAlign.center,
                style: TextStyle(
                    fontSize: 14,
                    color: textColor,
                    fontWeight: FontWeight.bold),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
