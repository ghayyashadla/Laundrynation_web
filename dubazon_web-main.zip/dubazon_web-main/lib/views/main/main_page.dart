import 'dart:async';

import 'package:connectivity/connectivity.dart';
import 'package:dubazon/models/user.dart';
import 'package:dubazon/utils/auth.dart';
import 'package:dubazon/views/home/home_page.dart';
import 'package:dubazon/views/main/widgets/side_nav.dart';
import 'package:dubazon/views/members/members_page.dart';
import 'package:dubazon/views/alert/alert_page.dart';
import 'package:dubazon/views/packages/packages_page.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:restart_app/restart_app.dart';

import '../../main.dart';
// import 'package:internet_connection_checker/internet_connection_checker.dart';

class MainPage extends StatefulWidget {
  const MainPage({Key? key, required this.user}) : super(key: key);
  final MyUser user;

  @override
  State<MainPage> createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> with TickerProviderStateMixin {
  late TabController _tabController;
  final GlobalKey<ScaffoldState> scaffoldKey = GlobalKey();
  bool isDeviceConnected = false;
  final AuthService _auth = AuthService();

  late StreamSubscription<ConnectivityResult> subscription;

  Future<bool> _onLogout() async {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Are you sure?'),
        content: const Text('Do you want to Logout'),
        actions: <Widget>[
          GestureDetector(
            onTap: () => Navigator.of(context).pop(false),
            child: const SizedBox(width: 40, height: 25, child: Text("NO")),
          ),
          const SizedBox(height: 16),
          GestureDetector(
            onTap: () async {
              await _auth.signOut().then((value) => {Restart.restartApp()});
            },
            child: const SizedBox(width: 40, height: 25, child: Text("YES")),
          ),
        ],
      ),
    );
    return true;
  }

  @override
  void initState() {
    super.initState();
    _tabController = TabController(
      vsync: this,
      length: 4,
      initialIndex: 0,
    );
    // subscription = Connectivity()
    //     .onConnectivityChanged
    //     .listen((ConnectivityResult result) async {
    //   if (result != ConnectivityResult.none) {
    //     isDeviceConnected = await InternetConnectionChecker().hasConnection;
    //   }
    // });

    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      if (kDebugMode) {
        print('Notification Received with web page open');
      }
      RemoteNotification? notification = message.notification;
      AndroidNotification? android = message.notification?.android;
      if (notification != null && android != null) {
        flutterLocalNotificationsPlugin.show(
            notification.hashCode,
            notification.title,
            notification.body,
            NotificationDetails(
              android: AndroidNotificationDetails(
                channel.id,
                channel.name,
                channelDescription: channel.description,
                color: Colors.blue,
                playSound: true,
                // icon: '@mipmap/ic_lancher',
                icon: 'icon',
              ),
            ));
      }
    });

    FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
      if (kDebugMode) {
        print('A new messageopen app event was published');
      }
      RemoteNotification? notification = message.notification;
      AndroidNotification? android = message.notification?.android;
      if (notification != null && android != null) {
        showDialog(
            context: context,
            builder: (_) {
              return AlertDialog(
                title: Text("${notification.title}"),
                content: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [Text("${notification.body}")],
                  ),
                ),
              );
            });
      }
    });

    // FirebaseMessaging.instance.subscribeToTopic('subscription');
  }

  @override
  void dispose() {
    super.dispose();
    subscription.cancel();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      body: WillPopScope(
        onWillPop: () {
          Navigator.pop(context);
          return Future(() => true);
        },
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SideNavigationBar(
                onLogout: _onLogout, tabController: _tabController),
            Expanded(
              child: TabBarView(
                  physics: const NeverScrollableScrollPhysics(),
                  controller: _tabController,
                  children: [
                    HomePage(user: widget.user, scaffoldKey: scaffoldKey),
                    PackagesPage(user: widget.user, scaffoldKey: scaffoldKey),
                    MembersPage(user: widget.user, scaffoldKey: scaffoldKey),
                    AlertPage(user: widget.user, scaffoldKey: scaffoldKey),
                  ]),
            ),
          ],
        ),
      ),
    );

    //  Scaffold(
    //   body: Row(
    //     children: <Widget>[
    //       NavigationRail(
    //         selectedIndex: _selectedIndex,
    //         onDestinationSelected: (int index) {
    //           setState(() {
    //             _selectedIndex = index;
    //           });
    //         },
    //         labelType: NavigationRailLabelType.selected,
    //         destinations: const <NavigationRailDestination>[
    //           NavigationRailDestination(
    //             icon: Icon(Icons.favorite_border),
    //             selectedIcon: Icon(Icons.favorite),
    //             label: Text('First'),
    //           ),
    //           NavigationRailDestination(
    //             icon: Icon(Icons.bookmark_border),
    //             selectedIcon: Icon(Icons.book),
    //             label: Text('Second'),
    //           ),
    //           NavigationRailDestination(
    //             icon: Icon(Icons.star_border),
    //             selectedIcon: Icon(Icons.star),
    //             label: Text('Third'),
    //           ),
    //         ],
    //       ),
    //       const VerticalDivider(thickness: 1, width: 1),
    //       // This is the main content.
    //       Expanded(
    //         child: Center(
    //           child: Text('selectedIndex: $_selectedIndex'),
    //         ),
    //       )
    //     ],
    //   ),
    // );
  }
}
