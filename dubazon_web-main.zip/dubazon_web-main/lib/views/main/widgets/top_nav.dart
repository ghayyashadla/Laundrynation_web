import 'package:dubazon/views/widgets/button.dart';
import 'package:flutter/material.dart';

AppBar topNavigationBar(
  GlobalKey<ScaffoldState> key,
  title,
  buttonTitle,
  onButtonPressed,
  buttonTitle2,
  onButtonPressed2,
) =>
    AppBar(
      backgroundColor: Colors.white,
      title: Column(
        children: [
          Text(
            title,
            style: const TextStyle(
              color: Colors.black54,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
      actions: [
        if (buttonTitle2 != null)
          Container(
            margin: const EdgeInsets.symmetric(vertical: 14, horizontal: 20),
            child: Button(
              onPressed: onButtonPressed2,
              text: buttonTitle2,
            ),
          ),
        if (buttonTitle != null)
          Container(
            margin: const EdgeInsets.symmetric(vertical: 14, horizontal: 20),
            child: Button(
              onPressed: onButtonPressed,
              text: buttonTitle,
            ),
          ),
      ],
    );
