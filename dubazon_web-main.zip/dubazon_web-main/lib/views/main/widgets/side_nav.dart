import 'package:dubazon/constants.dart';
import 'package:dubazon/utils/auth.dart';
import 'package:flutter/material.dart';
import 'package:restart_app/restart_app.dart';

class SideNavigationBar extends StatefulWidget {
  const SideNavigationBar(
      {Key? key, required this.onLogout, required this.tabController})
      : super(key: key);
  final Function() onLogout;
  final TabController tabController;

  @override
  State<SideNavigationBar> createState() => _SideNavigationBarState();
}

class _SideNavigationBarState extends State<SideNavigationBar> {
  int _selected = 0;
  final AuthService _auth = AuthService();

  _onLogout() async {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Are you sure?'),
        content: const Text('Do you want to Logout'),
        actions: <Widget>[
          GestureDetector(
            onTap: () => Navigator.of(context).pop(false),
            child: const SizedBox(width: 40, height: 25, child: Text("NO")),
          ),
          const SizedBox(height: 16),
          GestureDetector(
            onTap: () async {
              await _auth.signOut().then((value) => {Restart.restartApp()});
            },
            child: const SizedBox(width: 40, height: 25, child: Text("YES")),
          ),
        ],
      ),
    );
    return true;
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 60,
      color: kPrimaryColor,
      padding: const EdgeInsets.all(4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          const SizedBox(height: 20),
          AspectRatio(
            aspectRatio: 1,
            child: Container(
              margin: const EdgeInsets.all(6),
              // padding: const EdgeInsets.all(2),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(6),
                gradient: const RadialGradient(
                  colors: [
                    Colors.white,
                    Colors.grey,
                  ],
                  radius: 1.5,
                ),
              ),
              child: Center(
                child: Image.asset(
                  "images/dubazon_logo.png",
                  width: 50,
                ),
              ),
            ),
          ),
          const SizedBox(height: 20),
          InkWell(
            onTap: () {
              widget.tabController.animateTo(0);
              setState(() {
                _selected = 0;
              });
            },
            child: AspectRatio(
              aspectRatio: 1,
              child: Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: _selected == 0 ? Colors.white.withOpacity(0.2) : null,
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Center(
                  child: Column(
                    children: [
                      const Icon(
                        Icons.dashboard_outlined,
                        color: Colors.white,
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Requests',
                        style: TextStyle(
                          fontSize: 7,
                          color: Colors.white.withOpacity(0.8),
                        ),
                      )
                    ],
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 10),
          InkWell(
            onTap: () {
              widget.tabController.animateTo(1);
              setState(() {
                _selected = 1;
              });
            },
            child: AspectRatio(
              aspectRatio: 1,
              child: Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: _selected == 1 ? Colors.white.withOpacity(0.2) : null,
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Center(
                  child: Column(
                    children: [
                      const Icon(
                        Icons.local_offer_outlined,
                        color: Colors.white,
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Packages',
                        style: TextStyle(
                          fontSize: 8,
                          color: Colors.white.withOpacity(0.8),
                        ),
                      )
                    ],
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 10),
          InkWell(
            onTap: () {
              widget.tabController.animateTo(2);
              setState(() {
                _selected = 2;
              });
            },
            child: AspectRatio(
              aspectRatio: 1,
              child: Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: _selected == 2 ? Colors.white.withOpacity(0.2) : null,
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Center(
                  child: Column(
                    children: [
                      const Icon(
                        Icons.group_add_outlined,
                        color: Colors.white,
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Members',
                        style: TextStyle(
                          fontSize: 8,
                          color: Colors.white.withOpacity(0.8),
                        ),
                      )
                    ],
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 10),
          // TabBar(
          //   controller: _tabController,
          //   indicatorColor: Colors.transparent,
          //   unselectedLabelColor: Colors.grey,
          //   labelColor: kPrimaryColor,
          //   tabs: const <Widget>[
          //     Tab(
          //       icon: Icon(Icons.home),
          //     ),
          //     Tab(
          //       icon: Icon(Icons.home),
          //     )
          //   ],
          // ),
          const Spacer(),
          const SizedBox(height: 10),
          InkWell(
            onTap: () {
              widget.tabController.animateTo(3);
              setState(() {
                _selected = 3;
              });
            },
            child: AspectRatio(
              aspectRatio: 1,
              child: Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: _selected == 3 ? Colors.white.withOpacity(0.2) : null,
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Center(
                  child: Column(
                    children: [
                      const Icon(
                        Icons.notifications_none_outlined,
                        color: Colors.white,
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Notification',
                        style: TextStyle(
                          fontSize: 7,
                          color: Colors.white.withOpacity(0.8),
                        ),
                      )
                    ],
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 10),
          // AspectRatio(
          //   aspectRatio: 1,
          //   child: Container(
          //     padding: const EdgeInsets.all(6),
          //     decoration: BoxDecoration(
          //       borderRadius: BorderRadius.circular(6),
          //     ),
          //     child: Center(
          //       child: Column(
          //         children: [
          //           const Icon(
          //             Icons.help_outline_rounded,
          //             color: Colors.white,
          //           ),
          //           const SizedBox(height: 4),
          //           Text(
          //             'Help',
          //             style: TextStyle(
          //               fontSize: 7,
          //               color: Colors.white.withOpacity(0.8),
          //             ),
          //           )
          //         ],
          //       ),
          //     ),
          //   ),
          // ),
          // const SizedBox(height: 10),
          Material(
            color: Colors.transparent,
            child: PopupMenuButton(
              child: AspectRatio(
                aspectRatio: 1,
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: const Center(
                    child: Icon(
                      Icons.account_circle,
                      color: Colors.white,
                      size: 35,
                    ),
                  ),
                ),
              ),
              itemBuilder: (context) {
                return List.generate(1, (index) {
                  return PopupMenuItem(
                    onTap: _onLogout,
                    child: Row(
                      children: const [
                        Icon(Icons.logout, color: Colors.black),
                        Text(
                          '   Log out',
                          style: TextStyle(
                              fontWeight: FontWeight.bold, color: Colors.black),
                        ),
                      ],
                    ),
                  );
                });
              },
            ),
          ),
          const SizedBox(height: 10),
        ],
      ),
    );
  }
}
