import 'package:dubazon/constants.dart';
import 'package:dubazon/models/member_request.dart';
import 'package:dubazon/models/user.dart';
import 'package:dubazon/utils/database.dart';
import 'package:dubazon/views/members/widgets/member_slot.dart';
import 'package:flutter/material.dart';

class MembersList extends StatefulWidget {
  const MembersList({Key? key, required this.user, required this.onMenu})
      : super(key: key);

  final MyUser user;
  final Function(MemberRequest) onMenu;

  @override
  State<MembersList> createState() => MembersListState();
}

class MembersListState extends State<MembersList> {
  late DatabaseService _database;

  List<MemberRequest> _memberRequests = [];

  getRequests() async {
    _memberRequests = await _database.getMemberRequests;
    if (mounted) setState(() {});
  }

  @override
  void initState() {
    super.initState();
    _database = DatabaseService(
        uid: widget.user.uid!, isAnonymous: widget.user.isAnonymous!);
    getRequests();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: kScaffoldColor,
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            height: 30,
            child: Row(
              children: const [
                SizedBox(width: 60),
                SizedBox(
                  width: 120,
                  child: Center(
                    child: Text(
                      'CUSTOMER',
                      style: TextStyle(fontSize: 12, color: Colors.black87),
                    ),
                  ),
                ),
                SizedBox(width: 10),
                SizedBox(
                  width: 140,
                  child: Center(
                    child: Text(
                      'EMAIL',
                      style: TextStyle(fontSize: 12, color: Colors.black87),
                    ),
                  ),
                ),
                SizedBox(width: 10),
                SizedBox(
                  width: 120,
                  child: Center(
                    child: Text(
                      'PACKAGE',
                      style: TextStyle(fontSize: 12, color: Colors.black87),
                    ),
                  ),
                ),
                SizedBox(width: 10),
                SizedBox(
                  width: 120,
                  child: Center(
                    child: Text(
                      'PHONE',
                      style: TextStyle(fontSize: 12, color: Colors.black87),
                    ),
                  ),
                ),
                SizedBox(width: 5),
                Spacer(),
                SizedBox(width: 5),
                SizedBox(
                  width: 140,
                  child: Center(
                    child: Text(
                      'REQUESTED',
                      style: TextStyle(fontSize: 12, color: Colors.black87),
                    ),
                  ),
                ),
                SizedBox(width: 60),
              ],
            ),
          ),
          ListView.builder(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 10),
            scrollDirection: Axis.vertical,
            itemCount: _memberRequests.length,
            shrinkWrap: true,
            physics: const BouncingScrollPhysics(),
            itemBuilder: (context, index) {
              return MemberSlot(
                request: _memberRequests[index],
                index: index,
                onMenu: () {
                  widget.onMenu(_memberRequests[index]);
                },
              );
            },
          ),
        ],
      ),
    );
  }
}
