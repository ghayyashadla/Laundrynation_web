import 'package:dubazon/models/member_request.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class MemberSlot extends StatelessWidget {
  const MemberSlot(
      {Key? key, required this.request, required this.index, this.onMenu})
      : super(key: key);
  final MemberRequest request;
  final int index;
  final Function()? onMenu;
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 35,
      decoration: BoxDecoration(
        color: index.isEven ? Colors.white : Colors.transparent,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        children: [
          const SizedBox(width: 20),
          const SizedBox(
            width: 20,
            child: Icon(
              Icons.check_circle,
              color: Colors.grey,
              size: 16,
            ),
          ),
          const SizedBox(width: 10),
          Container(
            margin: const EdgeInsets.symmetric(vertical: 6),
            width: 2,
            height: double.infinity,
            color: Colors.grey.withOpacity(0.5),
          ),
          const SizedBox(width: 10),
          SizedBox(
            width: 120,
            child: Center(
              child: Text(
                request.name,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
            ),
          ),
          const SizedBox(width: 10),
          SizedBox(
            width: 140,
            child: Center(
              child: Text(
                request.email,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 12),
              ),
            ),
          ),
          const SizedBox(width: 10),
          SizedBox(
            width: 120,
            child: Center(
              child: Text(
                request.package,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 12),
              ),
            ),
          ),
          const SizedBox(width: 10),
          SizedBox(
            width: 120,
            child: Center(
              child: Text(
                request.phone,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 12),
              ),
            ),
          ),
          const SizedBox(width: 5),
          const Spacer(),
          const SizedBox(width: 5),
          SizedBox(
            width: 140,
            child: Center(
              child: Text(
                DateFormat.yMMMd().add_jm().format(request.timestamp.toDate()),
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 12),
              ),
            ),
          ),
          const SizedBox(width: 20),
          SizedBox(
            width: 20,
            child: InkWell(
              onTap: onMenu,
              child: const SizedBox(
                width: 30,
                child: Icon(
                  Icons.more_horiz,
                  color: Colors.black87,
                  size: 30,
                ),
              ),
            ),
          ), // SizedBox(
          //   width: 20,
          //   child: InkWell(
          //     onTap: onMenu,
          //     child: const Icon(
          //       Icons.more_horiz,
          //       color: Colors.black87,
          //       size: 20,
          //     ),
          //   ),
          // ),

          const SizedBox(width: 20),
        ],
      ),
    );
  }
}
