import 'package:dubazon/constants.dart';
import 'package:dubazon/models/member_request.dart';
import 'package:dubazon/models/user.dart';
import 'package:dubazon/utils/database.dart';
import 'package:dubazon/views/main/widgets/top_nav.dart';
import 'package:dubazon/views/members/widgets/members_list.dart';
import 'package:dubazon/views/widgets/button.dart';
import 'package:flutter/material.dart';
import 'package:form_field_validator/form_field_validator.dart';

class MembersPage extends StatefulWidget {
  const MembersPage({Key? key, required this.user, required this.scaffoldKey})
      : super(key: key);
  final MyUser user;
  final GlobalKey<ScaffoldState> scaffoldKey;

  @override
  State<MembersPage> createState() => _MembersPageState();
}

class _MembersPageState extends State<MembersPage> {
  late DatabaseService _database;
  String? _name, _desc;
  final _formKey = GlobalKey<FormState>();

  final _focus = FocusNode();

  Future<void> _onMenuClick(MemberRequest request) async {
    return showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        backgroundColor: kScaffoldColor,
        title: Stack(
          children: [
            Positioned(
              top: 0,
              bottom: 0,
              right: 0,
              child: IconButton(
                padding: EdgeInsets.zero,
                onPressed: () => Navigator.of(context).pop(false),
                icon: const Icon(Icons.close_rounded),
              ),
            ),
            Center(
              child: Text(
                'Generate message for ${request.name}',
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
            ),
          ],
        ),
        content: SizedBox(
          width: 500,
          height: 400,
          child: Form(
            key: _formKey,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Container(
                  margin: const EdgeInsets.symmetric(vertical: 10),
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(8),
                    boxShadow: const [
                      BoxShadow(
                        color: Colors.black12,
                        offset: Offset(2, 2),
                        blurRadius: 10,
                      ),
                    ],
                  ),
                  child: TextFormField(
                    initialValue: _name,
                    textInputAction: TextInputAction.next,
                    onFieldSubmitted: (v) {
                      FocusScope.of(context).requestFocus(_focus);
                    },
                    onChanged: (input) => _name = input.trim(),
                    decoration: const InputDecoration(
                      border: InputBorder.none,
                      hintStyle: TextStyle(fontSize: 14),
                      hintText: 'Heading',
                    ),
                    validator: MultiValidator(
                      [
                        RequiredValidator(errorText: 'Required *'),
                      ],
                    ),
                  ),
                ),
                Container(
                  margin: const EdgeInsets.symmetric(vertical: 10),
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(8),
                    boxShadow: const [
                      BoxShadow(
                        color: Colors.black12,
                        offset: Offset(2, 2),
                        blurRadius: 10,
                      ),
                    ],
                  ),
                  child: TextFormField(
                    initialValue: _desc,
                    textInputAction: TextInputAction.next,
                    // onFieldSubmitted: (v) {_onCreate(); },
                    onChanged: (input) => _desc = input.trim(),
                    decoration: const InputDecoration(
                      border: InputBorder.none,
                      hintStyle: TextStyle(fontSize: 14),
                      hintText: 'Description',
                    ),
                    validator: MultiValidator(
                      [
                        RequiredValidator(errorText: 'Required *'),
                      ],
                    ),
                  ),
                ),
                const Spacer(),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Button(
                      text: 'Done',
                      width: 100,
                      onPressed: () => _onCreate('USER', request.uid),
                    ),
                  ],
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  _onCreate(String type, String uid) {
    if (_formKey.currentState!.validate()) {
      _database
          .notify(type == 'ALERT' ? widget.user.uid! : uid, '', _name!, _desc!,
              type)
          .then((value) {
        Navigator.of(context).pop(true);
      });
    }
  }

  _onTap() async {
    return showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        backgroundColor: kScaffoldColor,
        title: Stack(
          children: [
            Positioned(
              top: 0,
              bottom: 0,
              right: 0,
              child: IconButton(
                padding: EdgeInsets.zero,
                onPressed: () => Navigator.of(context).pop(false),
                icon: const Icon(Icons.close_rounded),
              ),
            ),
            const Center(
              child: Text(
                'Generate new alert for all users',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
            ),
          ],
        ),
        content: SizedBox(
          width: 500,
          height: 400,
          child: Form(
            key: _formKey,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Container(
                  margin: const EdgeInsets.symmetric(vertical: 10),
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(8),
                    boxShadow: const [
                      BoxShadow(
                        color: Colors.black12,
                        offset: Offset(2, 2),
                        blurRadius: 10,
                      ),
                    ],
                  ),
                  child: TextFormField(
                    initialValue: _name,
                    textInputAction: TextInputAction.next,
                    onFieldSubmitted: (v) {
                      FocusScope.of(context).requestFocus(_focus);
                    },
                    onChanged: (input) => _name = input.trim(),
                    decoration: const InputDecoration(
                      border: InputBorder.none,
                      hintStyle: TextStyle(fontSize: 14),
                      hintText: 'Heading',
                    ),
                    validator: MultiValidator(
                      [
                        RequiredValidator(errorText: 'Required *'),
                      ],
                    ),
                  ),
                ),
                Container(
                  margin: const EdgeInsets.symmetric(vertical: 10),
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(8),
                    boxShadow: const [
                      BoxShadow(
                        color: Colors.black12,
                        offset: Offset(2, 2),
                        blurRadius: 10,
                      ),
                    ],
                  ),
                  child: TextFormField(
                    initialValue: _desc,
                    textInputAction: TextInputAction.next,
                    // onFieldSubmitted: (v) {_onCreate(); },
                    onChanged: (input) => _desc = input.trim(),
                    decoration: const InputDecoration(
                      border: InputBorder.none,
                      hintStyle: TextStyle(fontSize: 14),
                      hintText: 'Description',
                    ),
                    validator: MultiValidator(
                      [
                        RequiredValidator(errorText: 'Required *'),
                      ],
                    ),
                  ),
                ),
                const Spacer(),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Button(
                      text: 'Done',
                      width: 100,
                      onPressed: () => _onCreate('ALERT', widget.user.uid!),
                    ),
                  ],
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  void initState() {
    super.initState();
    _database = DatabaseService(
        uid: widget.user.uid!, isAnonymous: widget.user.isAnonymous!);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: topNavigationBar(widget.scaffoldKey, 'Membership Requests',
          'Generate Alert', _onTap, null, null),
      body: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        child: MembersList(
          user: widget.user,
          onMenu: _onMenuClick,
        ),
      ),
    );
  }
}
